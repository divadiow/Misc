/*
 * @Author: jiejie
 * @Github: https://github.com/jiejieTop
 * @Date: 2020-02-25 06:01:24
 * @LastEditTime: 2020-02-25 09:28:09
 * @Description: the code belongs to jiejie, please keep the author information and source code according to the license.
 */

#ifndef _SALOF_CONFIG_H_
#define _SALOF_CONFIG_H_

#include "http_config.h"

#endif /* _SALOF_CONFIG_H_ */
