
#ifndef _TXW4101_803_DEVICE_H_
#define _TXW4101_803_DEVICE_H_

extern void device_init(void);

#endif
