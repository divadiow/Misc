#!/bin/bash
rm -f Obj/common_common.o
