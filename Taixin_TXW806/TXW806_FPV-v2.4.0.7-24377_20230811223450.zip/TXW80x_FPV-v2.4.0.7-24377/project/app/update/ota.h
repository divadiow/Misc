#ifndef _OTA_H_
#define _OTA_H_




void ota_Tcp_Server();
int get_global_ota_num();
void set_global_ota_num(int num);








#endif
