

#include "no_frame_sd_save.h"

#if !FRAME_MANAGEMENT && OPENDML_EN &&  SDH_EN && FS_EN
#include "openDML.h"
#include "osal_file.h"
#include "media.h"
#include "osal/sleep.h"
#include "osal/string.h"
#include "jpgdef.h"

#include "newaudio.h"
#include "frame.h"


struct avi_head
{
	uint32 head;
	uint32 size;
};


/***************************************************
 * 非框架下的图片保存,使用的是非框架接口
***************************************************/
void save_pic(const char *path,void * get_f )
{
	uint8_t *jpeg_buf_addr;
	uint32 jpg_len = GET_JPG_LEN(get_f);
	uint32 w_len;
	int len;
	void *fp = osal_fopen("1.jpg","wb");
	if(!fp)
	{
		return;
	}
	while(1)
	{
		jpeg_buf_addr =(uint8_t*) GET_JPG_BUF(get_f);
		//所有节点已经读取完毕
		if(!jpeg_buf_addr || jpg_len == 0)
		{
			break;
		}

		//写入图片数据
		if(jpg_len > GET_NODE_LEN(get_f))
		{
			w_len = osal_fwrite(jpeg_buf_addr,1,GET_NODE_LEN(get_f),fp);

			if(w_len != GET_NODE_LEN(get_f))
			{
				len = -1;
				break;
			}
			
			len += GET_NODE_LEN(get_f);
			jpg_len -= GET_NODE_LEN(get_f);
		}
		else if(jpg_len)
		{
			w_len = osal_fwrite(jpeg_buf_addr,1,jpg_len,fp);

			if(w_len != jpg_len)
			{
				len = -1;
				break;
			}
			
			len += jpg_len;
			jpg_len = 0;
		}
		FREE_JPG_NODE(get_f);
	}

	if(fp)
	{
		osal_fclose(fp);
	}
}




/********************************************************
 * 录像使用
********************************************************/


#define RECORD_DIR "0:/DCIM"

/***************************************************
 * 音频写入的注册函数
 * fp:文件句柄
 * d:音频帧的结构体
 * flen:需要写入的音频数据长度
***************************************************/
int no_frame_record_audio(void *fp,void *d,int flen)
{
	if(!d)
	{
		return 1;
	}
	audio_el *audio_f = (audio_el*)d;
	uint8_t *buf = GET_AUDIO_BUF(audio_f);
	osal_fwrite(buf, flen, 1, fp);
	return 0;
}

/***************************************************
 * 视频写入的注册函数
 * fp:文件句柄
 * d:视频帧的结构体
 * flen:需要写入的视频数据长度
***************************************************/
int no_frame_record_video(void *fp,void *d,int flen)
{
    uint8_t *jpeg_buf_addr = NULL;
    void * get_f = (void *)d;
    uint32 jpg_len = flen;
    uint32_t w_len;
	int len = -1;
    while(1)
	{
		jpeg_buf_addr =(uint8_t*) GET_JPG_BUF(get_f);
		//printf("get_f:%X\taddr:%X\t%d\n",get_f,GET_JPG_BUF(get_f),GET_NODE_LEN(get_f));
		//所有节点已经读取完毕
		if(!jpeg_buf_addr || jpg_len == 0)
		{
			break;
		}

		//写入图片数据
		if(jpg_len > GET_NODE_LEN(get_f))
		{
			w_len = osal_fwrite(jpeg_buf_addr,1,GET_NODE_LEN(get_f),fp);

			if(w_len != GET_NODE_LEN(get_f))
			{
				len = -1;
				break;
			}
			
			len += GET_NODE_LEN(get_f);
			jpg_len -= GET_NODE_LEN(get_f);
		}
		else if(jpg_len)
		{
			w_len = osal_fwrite(jpeg_buf_addr,1,jpg_len,fp);

			if(w_len != jpg_len)
			{
				len = -1;
				break;
			}
			
			len += jpg_len;
			jpg_len = 0;
		}
		FREE_JPG_NODE(get_f);
	}
	return len;
}




//暂时fps只能是30帧,audiofrq如果是0,则是不带音频
int sd_save_avi(int *exit_flag,int fps,int audiofrq,int settime,int pic_w,int pic_h)
{
	if((*exit_flag) != RECORD_FLAG)
	{
		return -1;
	}
	void *get_f = NULL;
	void *pavi = NULL;
	int insert = 0;
	int tim_diff = 0;
	int err = -1;
	int count = 0;
	uint8_t *headerbuf = NULL;
	AVI_INFO *odmlmsg = NULL;
	ODMLBUFF *odml_buff = NULL;
	int timeouts = 0;
	audio_el *audio_f = NULL;
	int flen;



	pavi = create_video_file(RECORD_DIR);


	if(!pavi)
	{
		goto sd_save_avi_end;
	}
	odml_buff = malloc(sizeof(ODMLBUFF));
	odmlmsg = malloc(sizeof(AVI_INFO));
	headerbuf = malloc(_ODML_AVI_HEAD_SIZE__);
	ODMLbuff_init(odml_buff);


	odml_buff->ef_time = 1000/fps;
	odml_buff->ef_fps = fps;
	odml_buff->vframecnt = 0;
	odml_buff->aframecnt = 0;
	odml_buff->aframeSample = 0;//这里不赋值,等到第一帧音频帧来了才赋值
	odml_buff->sync_buf = headerbuf;
	odmlmsg->audiofrq = audiofrq;

	if(audiofrq)
	{
		odmlmsg->pcm = 1;
	}
	else
	{
		odmlmsg->pcm = 0;
	}
	odmlmsg->win_w = pic_w;//
	odmlmsg->win_h = pic_h;//

	err = OMDLvideo_header_write(NULL, pavi,odmlmsg,(ODMLAVIFILEHEADER *)headerbuf);
	if(err < 0)
	{
		os_printf("%s opendml write head fail\n",__FUNCTION__);
		goto sd_save_avi_end;
	}
	//进入写卡
	while(1)
	{
		get_f = (void*)GET_JPG_FRAME();
		audio_f = GET_AUDIO_FRAME();
		if(audio_f && audiofrq == 0)
		{
			audio_f->free(audio_f);
			audio_f = NULL;
			printf("$");
		}
        else if(!odml_buff->aframeSample && audio_f)
        {
            odml_buff->aframeSample = GET_AUDIO_LEN(audio_f);
        }

		if(get_f)
		{
			
			timeouts = 0;
			printf("&");
			odml_buff->cur_timestamp = os_jiffies();
			//err = no_framememt_write_opendml(odml_buff,pavi,GET_JPG_LEN(get_f),get_f);
            err = opendml_write_video2(odml_buff,pavi,no_frame_record_video,GET_JPG_LEN(get_f),get_f);
			DEL_JPG_FRAME(get_f);
			get_f = NULL;
			if(err < 0)
			{
				os_printf("%s no_framememt_write_opendml fail\n",__FUNCTION__);
				goto sd_save_avi_end;
			}
			if(os_jiffies()-odml_buff->cur_timestamp > 500)
			{
				os_printf("time err:%d\n",os_jiffies()-odml_buff->cur_timestamp);
					
			}
			count ++;	
			insert = insert_frame(odml_buff,pavi,&tim_diff);
			odml_buff->last_timestamp = odml_buff->cur_timestamp ;
			count += insert;

			if((*exit_flag)!= RECORD_FLAG || count>30*settime)
			{
				stdindx_updata(pavi,odml_buff);
				ODMLUpdateAVIInfo(pavi,odml_buff,odmlmsg->pcm,NULL,(ODMLAVIFILEHEADER *)headerbuf);
				osal_fclose(pavi);
				pavi = NULL;
				count = 0;
				break;
			}
		}



		//音频写入
		if(audio_f)
		{
			flen = GET_AUDIO_LEN(audio_f);	
			opendml_write_audio(odml_buff,pavi,no_frame_record_audio,flen,audio_f);

			audio_f->free(audio_f);
			audio_f = NULL;
			printf("^");
		}


		if(!get_f && !audio_f)
		{
			os_sleep_ms(1);
			if(pavi)
			{
				timeouts++;
				if(timeouts>1000)
				{
					if(count > 0)
					{
						stdindx_updata(pavi,odml_buff);
						ODMLUpdateAVIInfo(pavi,odml_buff,odmlmsg->pcm,NULL,(ODMLAVIFILEHEADER *)headerbuf);
					}
					osal_fclose(pavi);
					pavi = NULL;

					break;
				}
			}
		}
	}

	sd_save_avi_end:
	os_printf("%s end\n",__FUNCTION__);
	if(odml_buff)
	{
		free(odml_buff);
		odml_buff = NULL;
	}

	if(odmlmsg)
	{
		free(odmlmsg);
		odmlmsg = NULL;
	}

	if(headerbuf)
	{
		free(headerbuf);
		headerbuf = NULL;
	}

	if(get_f)
	{
		DEL_JPG_FRAME(get_f);
	}
	return err;
}
#endif