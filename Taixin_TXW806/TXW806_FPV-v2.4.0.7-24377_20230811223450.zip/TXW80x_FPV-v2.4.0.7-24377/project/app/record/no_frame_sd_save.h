#ifndef __NO_FRAME_SD_SAVE_H
#include "typesdef.h"
#include "sys_config.h"
void save_pic(const char *path,void * get_f);
int sd_save_avi(int *exit_flag,int fps,int audiofrq,int settime,int pic_w,int pic_h);
#endif