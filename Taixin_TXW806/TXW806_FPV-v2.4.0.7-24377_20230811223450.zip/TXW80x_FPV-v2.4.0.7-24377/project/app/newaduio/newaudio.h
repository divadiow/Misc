#ifndef __NEWAUDIO_H
#define __NEWAUDIO_H
#include "typesdef.h"
#include "list.h"
#include "dev.h"
#include "devid.h"
#include "osal/mutex.h"
#include "osal/irq.h"
#include "osal/task.h"
#define AUDIONUM	(8)
#define AUDIOLEN	(2048-8)
typedef struct audio_el audio_el;
typedef struct NewAudio NewAudio;
typedef void (*free_func)(void*node);

struct audio_el {
    unsigned char *audio_data;   //音频数据
    struct audio_el *next;
    int len;
    unsigned int timestamp;
    NewAudio *parent_priv;
    free_func free;         //释放函数
} ;

struct NewAudio
{
    void *data;//申请的空间
    void *list;//申请的链表空间
    void *pdm_msgq;
    void *audio_hardware_hdl;
    struct os_task     audio_demo_hdl;


    audio_el *free_list; //可用栈
    audio_el *ready_list;//准备好数据的栈
};

void *newaudio_task();
audio_el *global_ready_el();
unsigned char *get_el_buf(audio_el* el_node);
unsigned int  get_el_timestamp(audio_el* el_node);
int get_el_buf_len(audio_el* el_node);
#endif