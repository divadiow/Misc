#include "newaudio.h"
#include "osal/sleep.h"
#include "string.h"


#include "pdmFilter.h"
#include "pdm_audio.h"

#include "utlist.h"

#include "newaudio.h"


//对PCM数据的放大倍数，最大127*256
#define PCM_GAIN                                (10*256)//30*256//(22*256)


NewAudio *global_newaudio_priv = NULL;


static void rm_dc_filter_init(TYPE_FIRST_ORDER_FILTER_TYPE *filter)
{
    memset(filter, 0, sizeof(TYPE_FIRST_ORDER_FILTER_TYPE));
}






audio_el *global_ready_el()
{
    audio_el* el_node = NULL;
    if(global_newaudio_priv && global_newaudio_priv->ready_list)
    {
        el_node = global_newaudio_priv->ready_list;
        LL_DELETE(global_newaudio_priv->ready_list,el_node);
        return el_node;
    }
    return NULL;
}

unsigned char *get_el_buf(audio_el* el_node)
{
    if(el_node)
    {
        return el_node->audio_data;
    }
    return NULL;
}

unsigned int  get_el_timestamp(audio_el* el_node)
{
    if(el_node)
    {
        return el_node->timestamp;
    }
    return 0;
}


int get_el_buf_len(audio_el* el_node)
{
    if(el_node)
    {
        return el_node->len;
    }
    return 0;
}

void el_free(audio_el *node)
{
    LL_APPEND(node->parent_priv->free_list,node);
}
static void newaudio_deal_task(void *arg)
{
	 NewAudio *priv = (NewAudio *)arg;
     printf("priv:%X\n",priv);
	 int16* addr;
	 int res;
	 int i;
	 audio_el* node;
	 TYPE_FIRST_ORDER_FILTER_TYPE filter_ctl;
	 rm_dc_filter_init(&filter_ctl);
	 while(1)
	 {
		res = csi_kernel_msgq_get(priv->pdm_msgq,&node,-1);
		if(!res)
		{
            addr = node->audio_data;
		    for(i=0; i<AUDIOLEN/2; i++) 
            {
				addr[i] = rm_dc_filter(&filter_ctl, addr[i]);
				addr[i] = pcm_volum_gain(addr[i], PCM_GAIN);
			}

            //压入对应的链表
            
            LL_APPEND(priv->ready_list,node);
            #if 0
            if(node->free)
            {
                node->free(node);
            }
            #endif
		}
		else
		{
		 	printf("%s:%d err @@@@@@@@@@@@\n",__FUNCTION__,__LINE__);

		}
	 }
}

void *newaudio_creat() {

	unsigned char *data = (char*)malloc(AUDIONUM*AUDIOLEN);
    NewAudio *newaudio_priv = NULL;
	audio_el *free_list = NULL;
	newaudio_priv = (NewAudio*)malloc(sizeof(NewAudio));
	free_list = (audio_el*)malloc(AUDIONUM*sizeof(audio_el));
	if(!newaudio_priv || !free_list)
	{
		goto newaudio_creat_end;
	}
	memset(newaudio_priv,0,sizeof(NewAudio));
    memset(free_list,0,AUDIONUM*sizeof(audio_el));
    newaudio_priv->data = data;
    newaudio_priv->list = free_list;
    newaudio_priv->pdm_msgq = csi_kernel_msgq_new(1,sizeof(uint8_t*));




    //初始化可用的栈
    for(int i=0;i<AUDIONUM;i++)
    {
        free_list[i].audio_data = &data[AUDIOLEN*i];
        free_list[i].free = el_free;
        free_list[i].parent_priv = newaudio_priv;
        free_list[i].len = AUDIOLEN;
        LL_APPEND(newaudio_priv->free_list,&free_list[i]);
    }
	OS_TASK_INIT("hgpdm_sample_task", &newaudio_priv->audio_demo_hdl, newaudio_deal_task, newaudio_priv, OS_TASK_PRIORITY_NORMAL, 1024);
    global_newaudio_priv = newaudio_priv;
    return newaudio_priv;
	newaudio_creat_end:
    global_newaudio_priv = NULL;
	return NULL;
    
}


int newaudio_destory(void *priv_hdl)
{
	//struct audio_frame_priv *priv = (struct audio_frame_priv *)priv_hdl;
	int ret = RET_OK;

	//newaudio_destory_end:
	return ret;
}

static void *newaudio_set_buf(void *priv_el,void *el_point)
{
    NewAudio *newaudio_priv = (NewAudio *)priv_el;
    audio_el **point = (audio_el**)el_point;
    void *buf = NULL;
    audio_el *el_node = NULL;
    if(newaudio_priv->free_list)
    {
        el_node = newaudio_priv->free_list;
        LL_DELETE(newaudio_priv->free_list,el_node);
        buf = el_node->audio_data;
    }
    *point = el_node;
	return buf;
	
}

static void newaudio_get_buf(void *priv_el,void *el_point)
{
    NewAudio *priv = (NewAudio *)priv_el;
    
    audio_el *el_node = (audio_el*)el_point;
    int res;
	if(!el_node)
	{
		printf("%s:%d err\n",__FUNCTION__,__LINE__);
		return;
	}
    el_node->timestamp = os_jiffies();
	res = csi_kernel_msgq_put(priv->pdm_msgq,&el_node,0,0);
	//正常应该保证不进这里,如果进来代表任务没有获取队列,直接配置下一个buf导致的
	if(res)
	{
		if(el_node->free)
        {
            el_node->free(el_node);
        }
	}
	return;
	
}




void *newaudio_task()
{
	struct NewAudio *priv_el;
	void *audio_priv;
	priv_el = newaudio_creat();
	audio_priv = pdm_audio_open(PDM_SAMPLE_FREQ_16K,PDM_CHANNEL_RIGHT);
	if(audio_priv)
	{
		priv_el->audio_hardware_hdl = audio_priv;
		pdm_audio_register(audio_priv,priv_el,AUDIOLEN,newaudio_set_buf,newaudio_get_buf);
    	pdm_audio_start(audio_priv);
	}
	return (void*)priv_el;
}


