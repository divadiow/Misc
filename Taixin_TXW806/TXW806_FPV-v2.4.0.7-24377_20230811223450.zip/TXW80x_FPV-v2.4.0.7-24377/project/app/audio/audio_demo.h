#ifndef __AUDIO_DEMO_H
#define __AUDIO_DEMO_H
void audio_task(const char *name);
int audio_destory(void *priv_hdl);
void *audio_creat(void *argument);



#endif
