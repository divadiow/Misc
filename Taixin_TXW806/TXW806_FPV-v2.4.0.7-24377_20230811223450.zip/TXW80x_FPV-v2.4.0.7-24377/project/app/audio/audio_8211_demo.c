#include "typesdef.h"
#include "list.h"
#include "dev.h"
#include "devid.h"
#include "hal_i2s_audio.h"
#include "frame_memt.h"
#include "osal/task.h"
#include "hal/i2s.h"
#include "hal/i2c.h"
#include "osal_file.h"
#include "osal/sleep.h"




typedef struct audio_8211_frame_priv
{
	app_frame_management* speaker_afmemt;
}audio_8211_frame_priv;

typedef struct {
	struct list_head* (*get_frame)(app_frame_management* afmemt); 
	void (*del_frame)(struct list_head *d,app_frame_management* afmemt);
	int (*write)(void *fp,void *d,int flen);
}speaker_user_action;        //jpg的私有行为

static speaker_user_action speaker_action={
	.get_frame = get_app_node_from_deal_list_with_del,
	.del_frame = finish_app_node,
	.write     = NULL,
};


#define AUDIONUM	8
#define AUDIOLEN	1024




static void *audio_play_set_buf(void *priv_el,void *el_point,int *buf_size)
{
	audio_8211_frame_priv *priv = (audio_8211_frame_priv*)priv_el;
	speaker_user_action *speaker_act = NULL;
	void * get_f = NULL;
	void *buf = NULL;
	struct list_head **point = (struct list_head**)el_point;
	if(priv->speaker_afmemt)
	{	
		speaker_act = (speaker_user_action*)priv->speaker_afmemt->app_action;
	}
	else
	{
		return NULL;
	}

	get_f = speaker_act->get_frame(priv->speaker_afmemt);
	if(get_f)
	{
		buf = get_app_buf_adr(get_f);
		*buf_size = get_app_buf_len(get_f);
		*point = get_f;
	}
	else
	{
		printf("e");
		return NULL;
	}
	return buf;
	
}


//因为播放音频不需要get_buf,所以基本为空函数,或者处理上一次播放完毕的buf

static void audio_play_get_buf(void *priv_el,void *el_point,int *buf_size)
{

	audio_8211_frame_priv *priv = (audio_8211_frame_priv*)priv_el;
	struct list_head *get_f = (struct list_head*)el_point;
	speaker_user_action* speaker_act = NULL;
	if(!get_f)
	{
		printf("%s:%d err\n",__FUNCTION__,__LINE__);
		return;
	}
	if(priv->speaker_afmemt)
	{	
		speaker_act = (speaker_user_action*)priv->speaker_afmemt->app_action;
	}
	else
	{
		return ;
	}

	if(speaker_act)
	{
		speaker_act->del_frame(get_f,priv->speaker_afmemt);
		*buf_size = get_app_buf_len(get_f);
	}


	return;
	
}






static audio_8211_frame_priv *audio_8211_creat(const char *play_name) {
	int ret = 0;
	int res;
	const char *name = (const char *)play_name;
    struct audio_8211_frame_priv *priv = NULL;
	priv = (struct audio_8211_frame_priv*)malloc(sizeof(struct audio_8211_frame_priv));
	if(!priv)
	{
		ret = -1;
		goto audio_8211_creat_end;
	}
	memset(priv,0,sizeof(struct audio_8211_frame_priv));
	//喇叭的流框架连接,暂时播放pdm的音频
	//创建喇叭的框架空间,同时将麦克风的绑定到喇叭上
	app_analyze *audio_app_analyze = NULL;
	app_frame_management* speaker_afmemt = NULL;
	audio_app_analyze = find_app_analyze(name);
	if(audio_app_analyze)
	{
		speaker_afmemt = register_user_action(audio_app_analyze,(void*)&speaker_action,"speaker");
		app_node_init(speaker_afmemt,8);
		
		//创建speaker切换buf的任务
		priv->speaker_afmemt = speaker_afmemt;
		app_frame_enable(speaker_afmemt,1);
		printf("!!!!!!!!!!!!!!!!!!!!!!%s:%d\n",__FUNCTION__,__LINE__);
	}
	return priv;
	
	
	audio_8211_creat_end:
	printf("%s:%d err,ret:%d\n",__FUNCTION__,__LINE__,ret);
	if(priv)
	{
		free(priv);
	}
	return NULL;
    
}

static uint8 sim_mic_frame_buf[AUDIONUM * AUDIOLEN] __attribute__((aligned(4)));

#define MUSIC_FILE_NAME     "music16.pcm"

static void sim_mic_thread(void *arg)
{
	int res;
	int readLen;
	void *fp = osal_fopen(MUSIC_FILE_NAME,"rb");
	struct list_head* get_analy_node;
	app_analyze sim_mic_app_analyze;
	if(!fp)
	{
		printf("%s:%d no found file\n",__FUNCTION__,__LINE__);
	}

	printf("%s:%d\n",__FUNCTION__,__LINE__);

	res = app_analyze_init_with_name(&sim_mic_app_analyze,"pdm",AUDIONUM,sim_mic_frame_buf,AUDIOLEN);

	while(1)
	{
		get_analy_node = get_app_analyze_node(&sim_mic_app_analyze);
		if(get_analy_node)
		{
			//printf("rd:%X\n",get_real_buf_adr(get_analy_node));
			readLen = osal_fread(get_real_buf_adr(get_analy_node),1,AUDIOLEN,fp);
			if(readLen<=0)
			{
				if(readLen<0)
				{
					printf("%s:%d err\n",__FUNCTION__,__LINE__);
					return;
				}
				osal_fseek(fp,0);
				force_del_frame(get_analy_node);
				continue;
				
			}

			if(readLen<AUDIOLEN)
			{
				osal_fseek(fp,0);
			}
			
			//配置当前中断的buf
			set_app_buf_len(get_analy_node,readLen);
			map_realnode_2_app_node_msg(&sim_mic_app_analyze,get_analy_node);
			wake_up_analyze_list_app(&sim_mic_app_analyze);  
			printf("S");
			

		}
		else
		{
			//printf(".");
			os_sleep_ms(1);
		}
	}


}


#define PLAY_EMPTY_SIZE 1024

static struct os_task     sim_mic_task;

/**************************************
 * arg: name：播放音频源的名字(结合框架)
 * 
 * 
 * 
 *  
 * 
 ***************************************/
audio_8211_frame_priv * audio_8211_demo_init(const char *name)
{
	int ret;
	audio_i2s_config *play = NULL;
	void *empty_buf = NULL;
	play = (audio_i2s_config*)malloc(sizeof(audio_i2s_config));
	empty_buf = (void*)malloc(PLAY_EMPTY_SIZE);
	if(!play || !empty_buf)
	{
		printf("%s:%d\n",__FUNCTION__,__LINE__);
		goto audio_8311_demo_init_err;
	}
	memset(play,0,sizeof(audio_i2s_config));
	memset(empty_buf,0,PLAY_EMPTY_SIZE);

	//OS_TASK_INIT("sim_mic", &sim_mic_task, sim_mic_thread, (uint32)NULL, OS_TASK_PRIORITY_BELOW_NORMAL, 1024);
	//os_sleep_ms(200);

	//该任务及资源初始化
	audio_8211_frame_priv *audio_8211_priv = audio_8211_creat(name);
	//8311 install,注册对应函数
	//对play mic config初始化
	play->type = PLAY_MODE;
	play->i2s_devid = HG_IIS0_DEVID;
	play->sample_freq = I2S_SAMPLE_FREQ_16K;
	play->sample_bit = I2S_SAMPLE_BITS_16BITS;
	play->data_fmt= I2S_DATA_FMT_LSB;
	play->priv_el = audio_8211_priv;
	play->set_buf = audio_play_set_buf;
	play->get_buf = audio_play_get_buf;
	play->buf_size = PLAY_EMPTY_SIZE;
	play->play_empty_buf = empty_buf;
	int res = audio_i2s_install(play,NULL);
	printf("%s:%d res:%d\n",__FUNCTION__,__LINE__,res);

	//启动对应的任务
	return audio_8211_priv;


	audio_8311_demo_init_err:
	if(play)
	{
		free(play);
	}

	if(empty_buf)
	{
		free(empty_buf);
	}
	printf("%s:%d\n",__FUNCTION__,__LINE__);
	return NULL;
}

