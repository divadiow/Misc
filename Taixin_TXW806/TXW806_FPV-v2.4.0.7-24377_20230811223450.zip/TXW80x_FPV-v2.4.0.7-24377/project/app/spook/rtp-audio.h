#ifndef __RTP_AUDIO_H
#define __RTP_AUDIO_H
#include "stream.h"
struct rtp_media *new_rtp_media_audio_stream( struct stream *stream );

#endif
