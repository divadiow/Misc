#ifndef HTTP_SERVER_H
#define HTTP_SERVER_H


int http_server_init(uint32 ip);
#endif