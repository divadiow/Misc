#ifndef HTTPFILE_CLIENT_H
#define HTTPFILE_CLIENT_H

#define HTTP_DIR  "0:/HTTP"

int httpfile_client_init(uint32 ip);
#endif