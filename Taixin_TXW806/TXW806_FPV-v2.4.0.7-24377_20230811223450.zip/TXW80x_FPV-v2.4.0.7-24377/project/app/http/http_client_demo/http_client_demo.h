#ifndef HTTPS_CLIENT_H
#define HTTPS_CLIENT_H

#define HTTP_DIR  "0:/HTTP"

int http_client_init(uint32 ip);
#endif