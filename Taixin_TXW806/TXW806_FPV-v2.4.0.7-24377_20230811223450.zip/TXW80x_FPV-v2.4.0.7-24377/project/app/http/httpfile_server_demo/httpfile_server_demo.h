#ifndef HTTPFILE_SERVER_H
#define HTTPFILE_SERVER_H

#define HTTP_DIR  "0:/HTTP"

int httpfile_server_init(uint32 ip);
#endif