#ifndef __TK_TEST_H
#define __TK_TEST_H

#define TK_FLAG(x)			(1 << (x))

void tk_handle();
extern struct hgtk_param hgtk_config;

#define LED1	gpio_ioctl(PB_6 , GPIO_OUTPUT_TOGGLE, 1, 0);	
#define LED2	gpio_ioctl(PB_7 , GPIO_OUTPUT_TOGGLE, 1, 0);	
#define LED3	gpio_ioctl(PB_8 , GPIO_OUTPUT_TOGGLE, 1, 0);	
#define LED4	gpio_ioctl(PB_9 , GPIO_OUTPUT_TOGGLE, 1, 0);	
#define LED5	gpio_ioctl(PB_11, GPIO_OUTPUT_TOGGLE, 1, 0);	
#define LED6	gpio_ioctl(PB_10, GPIO_OUTPUT_TOGGLE, 1, 0);	

#endif