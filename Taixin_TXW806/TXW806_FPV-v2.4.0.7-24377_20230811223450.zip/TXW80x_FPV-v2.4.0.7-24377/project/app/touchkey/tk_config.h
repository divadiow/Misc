/**
  ***********************************************************************************************
  * @file    User/tk_config.h
  * @author  HUGE-IC Application Team
  * @version V1.0.0
  * @date    05-20-2022
  * @brief   Main program body
  ***********************************************************************************************
  * @attention
  * 按键基础功能配置：CS开关配置、调试功能开关、长按键时间、按键消抖次数等；
  * 按键系统配置：按键通道使能、按键通道灵敏度配置；
  *
  *
  ***********************************************************************************************
  */
#ifndef __TK_CONFIG_H
#define __TK_CONFIG_H
/* Includes ------------------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif
#define LP_CH(n)                        ((uint32)1 << (n))
/* Includes -------------------------------------------------------------------------------*/
/* Exported types -------------------------------------------------------------------------*/
#define TK_CHS0                         (0x00)
#define TK_CHS1                         (0x01)
#define TK_CHS2                         (0x02)
#define TK_CHS3                         (0x03)
#define TK_CHS4                         (0x04)
#define TK_CHS5                         (0x05)
#define TK_CHS6                         (0x06)
#define TK_CHS7                         (0x07)
#define TK_CHS8                         (0x08)
#define TK_CHS9                         (0x09)
#define TK_CHS10                        (0x0A)
#define TK_CHS11                        (0x0B)
#define TK_CHS12                        (0x0C)
#define TK_CHS13                        (0x0D)
#define TK_CHS14                        (0x0E)
#define TK_CHS15                        (0x0F)
#define TK_CHS16                        (0x10)
#define TK_CHS17                        (0x11)
#define TK_CHS18                        (0x12)
#define TK_CHS19                        (0x13)
#define TK_CHS20                        (0x14)
#define TK_CHS21                        (0x15)
#define TK_CHS22                        (0x16)
#define TK_CHS23                        (0x17)
#define TK_CHS24                        (0x18)
#define TK_CHS25                        (0x19)

/***************************************************************************************************/
#define TK_CH0_VALIB                    (1UL << 0)
#define TK_CH1_VALIB                    (1UL << 1)
#define TK_CH2_VALIB                    (1UL << 2)
#define TK_CH3_VALIB                    (1UL << 3)
#define TK_CH4_VALIB                    (1UL << 4)
#define TK_CH5_VALIB                    (1UL << 5)
#define TK_CH6_VALIB                    (1UL << 6)
#define TK_CH7_VALIB                    (1UL << 7)
#define TK_CH8_VALIB                    (1UL << 8)
#define TK_CH9_VALIB                    (1UL << 9)
#define TK_CH10_VALIB                   (1UL << 10)
#define TK_CH11_VALIB                   (1UL << 11)
#define TK_CH12_VALIB                   (1UL << 12)
#define TK_CH13_VALIB                   (1UL << 13)
#define TK_CH14_VALIB                   (1UL << 14)
#define TK_CH15_VALIB                   (1UL << 15)
#define TK_CH16_VALIB                   (1UL << 16)
#define TK_CH17_VALIB                   (1UL << 17)
#define TK_CH18_VALIB                   (1UL << 18)
#define TK_CH19_VALIB                   (1UL << 19)
#define TK_CH20_VALIB                   (1UL << 20)
#define TK_CH21_VALIB                   (1UL << 21)
#define TK_CH22_VALIB                   (1UL << 22)
#define TK_CH23_VALIB                   (1UL << 23)
#define TK_CH24_VALIB                   (1UL << 24)
#define TK_CH25_VALIB                   (1UL << 25)

/* Exported constants ---------------------------------------------------------------------*/
/** @defgroup XXX_LL_Register_Constants XXX LL Register Constants
  * @ingroup  XXX_LL_Driver
  * @brief    XXX LL register constant table definition
  *
  *
@verbatim
  ==========================================================================================
                                Register Constants
  ==========================================================================================

    Register Constants mainly encapsulates each bit in each group in the XXX
    register. In the process of configuration, the macro definition can be directly
    called to configure the XXX register, mainly for convenience. Understand the
    configuration of the XXX.

@endverbatim
  *
  * @{
  */

/************************************************************************************************
******************************用户配置区：user configuration area********************************
*************************************************************************************************/

/* 按键通道和灵敏度配置 **************************************************************************/
/*
 * 通道配置
 */
#define __TK_CH_INDEX                   {     \
  TK_CHS2, TK_CHS3, TK_CHS4, TK_CHS5,         \
}

/*
 * 通道灵敏配置
 */
#define __TK_CH_FTH                     {     \
	100,100, 100, 100,                        \
}

/*
 * 低功耗唤醒通道配置
 */
#define __TK_LP_CH                      (     \
)

/*
 * 调试IO配置
 */


/* 按键基础功能配置 *****************************************************************************/
#define TK_CS_EN                        (0)                 // 1: 开启CS功能;  0: 关闭CS功能
#define TK_DEBUG_EN                     (1)                 // 1: 开启调试功能;  0: 关闭调试功能
#define TK_DEBUG_CNT                    (5)                 // DEBUG打印延迟次数
#define TK_CH_USE                       (4)                 // 需要使用的按键个数
#define TK_MU_CNT                       (1)                 // 组合键个数
#define TK_NOISE_VAL                    (10)                // 按键噪声值

#define TK_TP_RATIO                     (0)                 // TP比例值
#define TK_FTH_RATIO                    (7)                 // 按键比例值
#define TK_NFTH_RATIO                   (5)                 // 噪声比例值
#define TK_NNFTH_RATIO                  (3)                 // 干扰比例值
#define TK_TP_CNT                       (15)                // TP确认次数
#define TK_CM_CNT                       (1)                 // 按键确认次数
#define TK_OPN_CNT                      (20)                // OVER正噪声确认次数
#define TK_UPN_CNT                      (30)                // UNPER正噪声确认次数
#define TK_ONN_CNT                      (20)                // OVER负噪声确认次数
#define TK_UNN_CNT                      (20)                // UNPER负噪声确认次数
#define TK_UTNN_CNT                     (20)                // 干扰确认次数
#define TK_MULT_CNT                     (5)                 // 按键个数大于组合按键确认次数
#define TK_LONG_KEY_TIME                (2000)              // 长按键时间(单位：1ms)
#define TK_VALID_TIME                   (5000)              // 按键有效时间(单位：1ms)   
#define TK_DIFF_MAX                     (50)
/**************************************************************************************************
*************************系统配置区：System configuration area*************************************
***************************************************************************************************/
/* 系统配置 ***************************************************************************************/
#define TK_RES_GEAR                     (7)                 // 常规放电电阻
#define TK_VOLT_REF_GEAR                (4)                 // 常规参考电压
#define TK_CURR_GEAR                    (78)                // 常规充电电流
#define TK_CONV_CNT                     (128)               // 常规单次转换时间((ana_conv_time+1)*8+1)*(TKPSRCNT+1)*Tclk Tclk = 1/(24MHz)
#define TK_PSR_CNT                      (179)               // 常规单位时间预分频(179+1)/180MHZ = 1us
#define TK_SCAN_FRE_DIV                 (60)                // 常规扫描时钟分频Fct = 180MHz/tk_base_div0
#define TK_CMP_FRE_DIV					(6)					// 常规扫描比较器时钟分频 Fcmp = 180Mhz/div					
/* 初始化系统配置 *******************************************************************************/
#define TK_DATA_LINE                    (2500)              // 按键目标线
#define TK_ADJUST_TIME                  (2000)              // 按键初始化时间(单位：1ms)
#define TK_MAX_DIFF_VALU                (100)               // 初始化最大差值
#define TK_ADJUST_EN                    (1)                 // 是否进行电流源自适应

#define TK_CT_GEAR				        (4)		            // Analog signal tk_ct control bits
/***************************************************************************************************/
/***************************************************************************************************/
/***************************************************************************************************/

/* Private macro ----------------------------------------------------------------------------------*/
/* Private variables ------------------------------------------------------------------------------*/
/* Private function prototypes --------------------------------------------------------------------*/
/* Private functions ------------------------------------------------------------------------------*/


#ifdef __cplusplus
}
#endif

#endif // __TK_CONFIG__

/**
  * @}
  */

/**
  * @}
  */

/*************************** (C) COPYRIGHT 2021 TAIXIN-IC ***** END OF FILE *************************/

