#include "typesdef.h"
#include "list.h"
#include "osal/sleep.h"
#include "osal/irq.h"
#include "osal/timer.h"
#include "osal/semaphore.h"
#include "errno.h"
#include "dev.h"
#include "devid.h"
#include "tk_config.h"

#include "hal/tk.h"
#include "hal/gpio.h"
#include "string.h"
#include "tk_user.h"
#include "tk_debug.h"
#include "drv_usart.h"



void led_gpio_init()
{
    PMU_REG_CLR_BITS(PMU->PMUCON11, BIT(17));
    PMU_REG_SET_BITS(PMU->PMUCON0, BIT(23)); 
	
	gpio_set_dir(PB_6, GPIO_DIR_OUTPUT);
	gpio_set_dir(PB_7, GPIO_DIR_OUTPUT);
	gpio_set_dir(PB_8, GPIO_DIR_OUTPUT);
	gpio_set_dir(PB_9, GPIO_DIR_OUTPUT);
	gpio_set_dir(PB_10, GPIO_DIR_OUTPUT);
	gpio_set_dir(PB_11, GPIO_DIR_OUTPUT);
	
	gpio_set_val(PB_6,  1);
	gpio_set_val(PB_7,  1);
	gpio_set_val(PB_8,  1);
	gpio_set_val(PB_9,  1);
	gpio_set_val(PB_10, 1);
	gpio_set_val(PB_11, 1);
}

void tk_struct_init()
{
    uint8 index = 0;
    volatile unsigned short fth[TK_CH_USE] = __TK_CH_FTH;
    volatile unsigned char   ch[TK_CH_USE] = __TK_CH_INDEX;
	
    memset(&hgtk_config, 0, sizeof(struct hgtk_param));

    hgtk_config.config[index++] = (0x7 | (TK_RES_GEAR << 3)); 	
    hgtk_config.config[index++] = (TK_CURR_GEAR);             	
    hgtk_config.config[index++] = (TK_VOLT_REF_GEAR << 3);    	
    hgtk_config.config[index++] = (0x50);                     	
    hgtk_config.config[index++] = (0x28);                     	
    hgtk_config.config[index++] = (TK_CONV_CNT);              	
    hgtk_config.config[index++] = (TK_PSR_CNT);               	
    hgtk_config.config[index++] = (TK_SCAN_FRE_DIV);          	
    hgtk_config.config[index++] = (0);                        	
    hgtk_config.config[index++] = (0);                        	
    hgtk_config.config[index++] = (0);                        	
    hgtk_config.config[index++] = (0x60);                     	
    hgtk_config.config[index++] = ((TK_CMP_FRE_DIV << 4) | 0x03);
    hgtk_config.config[index++] = (0x02);                     	
    hgtk_config.config[index++] = (0x07);                     	
    hgtk_config.config[index++] = (0x04);                     	
    hgtk_config.config[index++] = (0x07);

    index = 0;  
    hgtk_config.param[index++] = TK_TP_RATIO;
    hgtk_config.param[index++] = TK_FTH_RATIO;
    hgtk_config.param[index++] = TK_NFTH_RATIO;
    hgtk_config.param[index++] = TK_NNFTH_RATIO;
    hgtk_config.param[index++] = TK_TP_CNT;
    hgtk_config.param[index++] = TK_CM_CNT;
    hgtk_config.param[index++] = TK_OPN_CNT;
    hgtk_config.param[index++] = TK_UPN_CNT;
    hgtk_config.param[index++] = TK_ONN_CNT;
    hgtk_config.param[index++] = TK_UNN_CNT;
    hgtk_config.param[index++] = TK_UTNN_CNT;
    hgtk_config.param[index++] = TK_MULT_CNT;
    hgtk_config.param[index++] = TK_MU_CNT;
    hgtk_config.param[index++] = TK_DIFF_MAX; 

    hgtk_config.__tk_adjust_line      = TK_DATA_LINE;
    hgtk_config.__tk_adjust_time      = TK_ADJUST_TIME;
    hgtk_config.__tk_adjust_diff_valu = TK_MAX_DIFF_VALU;
    hgtk_config.__tk_adjust_en        = TK_ADJUST_EN;
    hgtk_config.__tk_valid_time       = TK_VALID_TIME;
    hgtk_config.__tk_long_key_time    = TK_LONG_KEY_TIME;
    hgtk_config.__tk_noise_value      = TK_NOISE_VAL;
    hgtk_config.__tk_cs_en            = TK_CS_EN;
    hgtk_config.__tk_use_num          = TK_CH_USE;
    hgtk_config.__time_base_cnt       = 0; 

    for (uint8 i = 0; i < TK_CH_USE; i++)
    {
        hgtk_config.__tk_i_set[i]    = TK_CURR_GEAR;
        hgtk_config.__tk_ch_fth[i]   = fth[i];
        hgtk_config.__tk_ch_index[i] = ch[i];
    }
}
void tk_param_init()
{
	printf("%s:%d\t\n",__FUNCTION__, __LINE__);

    tk_struct_init();

    /*LED gpio config*/
    led_gpio_init();

#if	TX_TOUCH_DEBUG 
	debug_uart_config();
#endif

	os_sleep_ms(100);
}

void user_handle(uint32 irq_flag, uint32 irq_data, uint32 key, uint32 printf_flag, uint32 debug_flag)
{
    uint8 temp[TK_CH_USE] = __TK_CH_INDEX;
    if (TK_IRQ_FLAG_GET_KEY_VALUE & irq_flag)
    {
        if(!(key & TK_KEY_TYPE_NONE))
        {
            if (key & BIT(temp[0]))
            {
                if (!printf_flag)
                {
                    disable_print(0);
                }else{
                    disable_print(1);
                }
                LED3;
            }
            if(key & BIT(temp[1]))
            {
                LED4;
            }
            if(key & BIT(temp[2]))
            {
                LED5;
            }
			if(key & BIT(temp[3]))
            {
                LED6;
            }
        }
		if(hgtk_config.__tk_long_key)
		{
			printf("data value is %d\r\n", hgtk_config.__tk_long_key);
			gpio_set_val(PB_8,  hgtk_config.__tk_index);
			gpio_set_val(PB_9,  hgtk_config.__tk_index);
			gpio_set_val(PB_10, hgtk_config.__tk_index);
			gpio_set_val(PB_11, hgtk_config.__tk_index);
			hgtk_config.__tk_index = !hgtk_config.__tk_index;
			
		}
        if (printf_flag && TX_TOUCH_DEBUG)
        {
            tk_debug_func(&hgtk_config, debug_flag);
        }
    }
}

void tk_handle()
{   
    struct tk_device *tk = (struct tk_device *)dev_get(HG_TOUCHKEY0_DEVID);;
    tk_param_init();
    tk_open(tk);
    tk_irq_request(tk, (tk_irq_hdl)user_handle, TK_IRQ_FLAG_GET_KEY_VALUE, 1);
}
