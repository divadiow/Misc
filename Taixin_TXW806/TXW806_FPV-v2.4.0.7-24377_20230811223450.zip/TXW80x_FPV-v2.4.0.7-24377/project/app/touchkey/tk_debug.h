
/**
  ******************************************************************************
  * @file     User/tk_debug.h
  * @author   TAIXIN-IC Application Team
  * @version  V1.0.0
  * @date     05-20-2022
  * @brief    Main program body.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2022 TAIXIN-IC</center></h2>
  *
  *
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __TK_DEBUG__
#define __TK_DEBUG__

#include "hal/tk.h"
#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
#define TX_TOUCH_DEBUG                                     	(1) 
extern struct uart_device *uart_dev;
#define tk_send_byte(ch)									uart_putc(uart_dev, ch)
/* Exported constants --------------------------------------------------------*/
void tk_debug_func(struct hgtk_param *cfg, uint32 flag);
void debug_uart_config(void);

/** @defgroup XXX_LL_Register_Constants XXX LL Register Constants
  * @ingroup  XXX_LL_Driver
  * @brief    XXX LL register constant table definition
  *
  *
@verbatim
  ===============================================================================
                                Register Constants
  ===============================================================================

    Register Constants mainly encapsulates each bit in each group in the XXX
    register. In the process of configuration, the macro definition can be directly
    called to configure the XXX register, mainly for convenience. Understand the
    configuration of the XXX.

@endverbatim
  *
  * @{
  */

/**
  * @}
  */
typedef struct _packheader
{
    uint8  pack_header;            // 包头码
    uint8  pack_curr_index;        // 包通道索引
    uint8  data_len;               // 数据长度
} TYPE_PACK_HEADER;

typedef struct _packstrcut
{
    uint16 data1;
    uint16 data2;
    uint16 data3;
} TYPE_PACK_STRCUT;

typedef struct __packtail
{
    uint8 tk_flag;
} TYPE_PACK_TAIL;


// 大端模式转换成小端模式
#define htol16(num) (((uint16)(num) >> 8) | ((uint16)(num) << 8))
#define htol32(num)	(((uint32)(num) >> 24) | 			   \
					(((uint32)(num) >> 8) & 0x0000FF00) |  \
					(((uint32)(num) << 8) & 0x00FF0000) |  \
					(((uint32)(num) << 24)))

// 最终发送函数
#define tk_send_start(pack_header)                                          \
{                                                                           \
    uint8 __check_sum = 0;                                                  \
    uint8 __i = 0;                                            		        \
    uint8 *__buf_point;                                                     \
    __buf_point = (uint8*)&pack_header;                                     \
    for(__i = 0;__i < sizeof(pack_header);__i++,__buf_point++) {            \
        tk_send_byte(*__buf_point);                                         \
        __check_sum ^= *__buf_point;                                        \
    }

#define tk_send_next(pack_strcut)                                           \
    __buf_point = (uint8*)&pack_strcut;                                     \
    for(__i = 0;__i < sizeof(pack_strcut);__i++,__buf_point++) {            \
        tk_send_byte(*__buf_point);                                         \
        __check_sum ^= *__buf_point;                                        \
    }

#define tk_send_end(pack_stop)                                              \
    __buf_point = (uint8*)&pack_stop;                                       \
    for(__i = 0;__i < sizeof(pack_stop);__i++,__buf_point++) {              \
        tk_send_byte(*__buf_point);                                         \
        __check_sum ^= *__buf_point;                                        \
    }                                                                       \
    tk_send_byte(__check_sum);                                              \
}
/**
  * @}
  */

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


#ifdef __cplusplus
}
#endif

#endif // __TK_DEBUG__

/**
  * @}
  */

/**
  * @}
  */

/*************************** (C) COPYRIGHT 2021 TAIXIN-IC ***** END OF FILE ****/
