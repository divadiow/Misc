/**
  ******************************************************************************
  * @file    User/tk_debug.c
  * @author  TAIXIN-IC Application Team
  * @version V1.0.0
  * @date    05-20-2022
  * @brief   Main program body
  ******************************************************************************
  * @attention
  * tk_debug.c文件是调试时使用的文件，不建议修改。
  * 以下函数和变量用户不需要修改
  *
  *
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "typesdef.h"
#include "list.h"
#include "errno.h"
#include "osal/irq.h"
#include "dev.h"
#include "devid.h"
#include "tk_debug.h"
#include "hal/uart.h"
#include "tk_config.h"


/** @addtogroup Template_Project
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/**
  * @}
  */
#if TX_TOUCH_DEBUG
#define USER_BAUD               (921600UL)
#define USER_UART_BAUD          ((SYSCLK-USER_BAUD)/(USER_BAUD))
#define RX_DMA_LEN              (29)

/**
  * @brief  uart配置函数
  * @param  None
  * @retval None
  */
struct uart_device *uart_dev = NULL;
void debug_uart_config(void)
{
    uart_dev = (struct uart_device *)dev_get(HG_UART1_DEVID);
	if (NULL == uart_dev) {
		printf("uart_device NULL\n");
	}
	// uart_open(uart_device, USER_BAUD);
}

// 包头字节
#define TK_HEADER_BYTE              (0xA5)
#define PACK_SEND_COUNT_ONCE        (4)


#if (TK_CH_USE % PACK_SEND_COUNT_ONCE)
#define PACK_IDX_MAX            (TK_CH_USE / PACK_SEND_COUNT_ONCE)
#define PACK_SEND_COUNT_FINAL   (TK_CH_USE % PACK_SEND_COUNT_ONCE)
#else
#define PACK_IDX_MAX            ((TK_CH_USE-1) / PACK_SEND_COUNT_ONCE)
#define PACK_SEND_COUNT_FINAL   PACK_SEND_COUNT_ONCE
#endif

/**
  * @brief  调试打印函数.
  * @param  None
  * @retval None
  */
void tk_debug_func(struct hgtk_param *cfg, uint32 flag)
{
    static uint8  cur_index = 0;
    static uint8  pack_index = 0;
    static uint16 i_set_cnt = 0;
    uint8 send_cnt = 0;

    TYPE_PACK_HEADER pack_header;
    TYPE_PACK_STRCUT pack_strcut;
    TYPE_PACK_TAIL   pack_tail;

    pack_header.pack_header = TK_HEADER_BYTE;
    pack_header.pack_curr_index = pack_index;

    if(pack_index == PACK_IDX_MAX)
    {
        send_cnt = PACK_SEND_COUNT_FINAL;
        pack_header.data_len = sizeof(pack_header) + sizeof(pack_strcut) * PACK_SEND_COUNT_FINAL + 2;
    } else {
        send_cnt = PACK_SEND_COUNT_ONCE;
        pack_header.data_len = sizeof(pack_header) + sizeof(pack_strcut) * PACK_SEND_COUNT_ONCE + 2;
    }

    tk_send_start(pack_header);

    do
    {
        pack_strcut.data1 = htol16(cfg->__tk_ch_data_1[cur_index]);
        pack_strcut.data2 = htol16(cfg->__tk_ch_data_0[cur_index]);
        if (i_set_cnt++ < 1000) {
            pack_strcut.data3 = htol16(cfg->__tk_i_set[cur_index]);
        } else {
            i_set_cnt = 1000;
            pack_strcut.data3 = htol16(cfg->__tk_ch_data_2[cur_index]);
        }
        tk_send_next(pack_strcut);
        send_cnt--;
        cur_index++;
    } while(send_cnt != 0);

    pack_tail.tk_flag = (flag >> (pack_index << 2)) & 0x0F;

    tk_send_end(pack_tail);

    if(pack_index == PACK_IDX_MAX)
    {
        pack_index = 0;
        cur_index = 0;
    } else {
        pack_index++;
    }
}
#endif

/*************************** (C) COPYRIGHT 2022 TAIXIN-IC ***** END OF FILE *****/
