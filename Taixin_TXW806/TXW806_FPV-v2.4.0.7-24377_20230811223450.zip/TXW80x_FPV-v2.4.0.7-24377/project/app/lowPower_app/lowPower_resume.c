#include "sys_config.h"
#include "typesdef.h"
#include "list.h"
#include "dev.h"
#include "devid.h"
#include "osal/string.h"
#include "pdm_audio.h"
/*

    休眠的伪代码:
    struct system_sleep_param sleep_args;
    memset(&sleep_args,0,sizeof(sleep_args));
    sleep_args.sleep_ms = 5000;
    sleep_args.wkup_io_en = 0x00;
    sleep_args.wkup_io_edge = 0x00;
    system_sleep(SYSTEM_SLEEP_TYPE_SRAM_WIFI, &sleep_args);



    休眠的注册函数:
    sys_register_sleepcb(jpeg_suspend_resume,NULL);
*/
void jpeg_suspend_resume(uint16 type, struct sys_sleepcb_param *args, uint32 priv)
{
	#if 1
	uint8 action = args->action;
	uint8 step = args->step;
    struct adc_device *hgadc = (struct adc_device *)dev_get(HG_ADC0_DEVID);
	printf("step:%d\n",step);
    switch(action)
    {
        case SYS_SLEEPCB_ACTION_SUSPEND:
            if(step == SYS_SLEEPCB_STEP_2)
            {
				#if SDH_EN && FS_EN
                fatfs_unregister();
				#endif
                #if DVP_EN	
                    void *dvp = (void *)dev_get(HG_DVP_DEVID);
                    if(dvp)
                    {
                        dvp_close(dvp);
                    }
                #endif
                
				#if AUDIO_EN
                audio_task_del();
				#endif

            }
            break;
        case SYS_SLEEPCB_ACTION_RESUME:
            if(step == SYS_SLEEPCB_STEP_2)
            {
				#if SDH_EN && FS_EN
					extern bool fatfs_register();
					sd_open();
					fatfs_register();
				#endif
				
				#if AUDIO_EN
					audio_task("pdm");
				#endif

                uint8 vcam_en();
                vcam_en();
                #if JPG_EN
                    void jpg_recfg();
                    jpg_recfg();
                #endif
                #if DVP_EN
                    bool csi_ret;
                    bool csi_cfg();
                    csi_ret = csi_cfg();
                #endif
                #if JPG_EN
                    void jpg_start();
                    jpg_start();
                #endif
                #if DVP_EN
                    bool csi_open();
                    if(csi_ret)
                        csi_open();
                #endif
            }
            break;
    }
	#endif
}
