#ifndef __REMOTE_CONTROL_H
#define __REMOTE_CONTROL_H
#include "avi_record.h"

void remote_control_Server(int port);

#endif
