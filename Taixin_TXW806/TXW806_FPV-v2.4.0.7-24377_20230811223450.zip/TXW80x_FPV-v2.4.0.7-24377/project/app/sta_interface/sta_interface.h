#ifndef _STA_INTERFACE_H_
#define _STA_INTERFACE_H_


void sta_send_udp_msg_init();


#endif
