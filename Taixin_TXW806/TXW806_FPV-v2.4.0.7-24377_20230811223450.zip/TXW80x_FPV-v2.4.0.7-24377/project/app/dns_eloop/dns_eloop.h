#ifndef _DNS_ELOOP_H_
#define _DNS_ELOOP_H_

int32 dns_start_eloop(char *ifname);
void dns_stop_eloop(char *ifname);

#endif

