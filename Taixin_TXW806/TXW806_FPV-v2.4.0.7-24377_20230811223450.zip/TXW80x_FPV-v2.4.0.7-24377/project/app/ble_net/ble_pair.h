#ifndef __BLE_PAIR_H
#define __BLE_PAIR_H

void ble_reset_pair_network(void *cb, uint8 type);

#endif