#ifndef _CARE_SKIN_H_
#define _CARE_SKIN_H_

typedef struct
{     
	uint8_t frame_num;
	uint8_t is_eof;
	uint8_t pkt_cnt;
	uint8_t size_H;
}care_skin_net_msg;





#endif
