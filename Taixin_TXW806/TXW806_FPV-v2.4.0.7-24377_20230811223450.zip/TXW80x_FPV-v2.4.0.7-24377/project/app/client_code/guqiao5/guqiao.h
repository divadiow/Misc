#ifndef _ALK_H_
#define _ALK_H_

typedef struct
{     
	uint8_t frame_num;
	uint8_t is_eof;
	uint8_t pkt_cnt;
	uint8_t res;
}alk_net_msg;





#endif
