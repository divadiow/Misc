#ifndef _USER_UDP_H_
#define _USER_UDP_H_

enum USER_UDP_CMD {
    USER_TICK_TIME               = 1,	   //usb复位
    MEMT_CMD,
    USER_FLY_CMD,
    CHG_UVC_IDX_CMD,
    SENSOR_LED_IDX_CMD,
    APP_SPOOK_OPEN,
};



#endif
