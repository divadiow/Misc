#include "sys_config.h"
#include "typesdef.h"
#include "list.h"
#include "errno.h"
#include "dev.h"
#include "osal/string.h"
#include "osal/irq.h"
#include "osal/semaphore.h"
#include "osal/mutex.h"
#include "osal/task.h"
#include "hal/netdev.h"
#include "hal/dma.h"
#include "hal/crc.h"
#include "lib/common/sysevt.h"
#include "lib/net/ethphy/eth_phy.h"
#include "lib/net/ethphy/eth_mdio_bus.h"
#include "dev/emac/hg_gmac_eva.h"
#include "hal/gpio.h"

extern int32 _os_task_set_priority(struct os_task *task, uint8 priority);
#define _OS_TASK_INIT(name, task, func, data, prio, stksize) do { \
        os_task_init((const uint8 *)name, task, (os_task_func_t)func, (uint32)data); \
        os_task_set_stacksize(task, stksize); \
        _os_task_set_priority(task, prio); \
        os_task_run(task);\
    }while(0)

//To fix gmac bugs
__weak void gmac_csr_dv_disable(int dev_id)
{
}

//To fix gmac bugs
__weak void gmac_csr_dv_enable(int dev_id)
{
}

static void hg_gmac_irq_handler(void *data)
{
    uint32 csr_temp;
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)data;

    HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR5);
    if (csr_temp & (HG_GMAC_CSR5_RI_PENDING | HG_GMAC_CSR5_RU_PENDING)) {
        //disable IRQ
        HG_GMAC_REG_OPT(dev->hw->CSR7 = ~(HG_GMAC_CSR7_AIE_EN | HG_GMAC_CSR7_NIE_EN | HG_GMAC_CSR7_RIE_EN | HG_GMAC_CSR7_RUE_EN));

        HG_GMAC_REG_OPT(dev->hw->CSR5 = HG_GMAC_CSR5_RI_PENDING);

        os_sema_up(&dev->receive_sema);
    }
}

static void hg_gmac_ru_handler(struct netdev *ndev)
{
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;
    uint32 csr_temp;

    /* rx suspend -> rx running */
    HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR5);

    if (csr_temp & HG_GMAC_CSR5_RU_PENDING) {
//        gmac_dbg("gmac_ru\r\n");

        HG_GMAC_REG_OPT(dev->hw->CSR5 = HG_GMAC_CSR5_RU_PENDING);

        dev->statistics.ru_pending_cnt++;

        /* In order to fix the bug that the rx state machine is stuck in suspend */
        /* CSR2 should be kicked after RU pending. */

        /* Turn off the CSR_DV function first. */
        gmac_csr_dv_disable(ndev->dev.dev_id);

        HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR6);

        if ((csr_temp & 0x00020000) == 0x00020000) {
            os_sleep_us(5);     //for 10Mbps, SYS_CLK = 48M
        } else {
            os_sleep_us(1);     //for 100Mbps, SYS_CLK = 48M
        }

#if HG_GMAC_FIX_BUG_RESET_EN
        /* Update the miss frame cnt. */
        HG_GMAC_REG_OPT(dev->ctrl_data.miss_frame_cnt = dev->hw->CSR8);
#endif
        HG_GMAC_REG_OPT(dev->hw->CSR2 = 0x0000);

        HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR6);
        if ((csr_temp & 0x00020000) == 0x00020000) {
            os_sleep_us(5);     //for 10Mbps, SYS_CLK = 48M
        } else {
            os_sleep_us(1);     //for 100Mbps, SYS_CLK = 48M
        }

        /* Finally resume the CSR_DV function */
        gmac_csr_dv_enable(ndev->dev.dev_id);
    }
}

//Ethernet receiving thread
static void hg_gmac_receive_frame_thread(void *argument)
{
    struct netdev *ndev = (struct netdev *)argument;
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;
#if HG_GMAC_FIX_BUG_RESET_EN
    uint32 csr_temp;
#endif

    while (1) {
        os_sema_down(&dev->receive_sema, osWaitForever);
#if HG_GMAC_FIX_BUG_RESET_EN
        if (dev->ctrl_data.reset_flag) {
            /* If there is no tx, you can reset. */
            if (dev->ctrl_data.tx_flag == 0) {
                hg_gmac_bug_reset(ndev);
            }
            continue;
        }

        dev->ctrl_data.rx_flag = 1;

        /* If there is frame loss but no RU pending, there must be a bug. */
        HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR8);
        if (csr_temp != dev->ctrl_data.miss_frame_cnt) {
            HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR5);
            if (!(csr_temp & HG_GMAC_CSR5_RU_PENDING)) {
                dev->ctrl_data.reset_flag = 1;
                dev->statistics.miss_err_cnt++;
                irq_disable(dev->irq_num);
                /* If there is no tx, you can reset. */
                dev->ctrl_data.rx_flag = 0;
                if (dev->ctrl_data.tx_flag == 0) {
                    hg_gmac_bug_reset(ndev);
                }
                continue;
            }
        }

        while (hg_gmac_has_received_frame(ndev) == RET_OK) {
            hg_gmac_receive_data(ndev);
            if (dev->ctrl_data.reset_flag) {
                break;
            }
        }

        /* 针对last descriptor先到，但是ru pending后到的情况，进行特殊处理。
         * 这种情况很可能在连续满带宽接收巨型帧的过程中出现。
         */
        hg_gmac_ru_handler(ndev);
        //clear pending
        HG_GMAC_REG_OPT(dev->hw->CSR5 = HG_GMAC_CSR5_RI_PENDING);
        //enable RI&RU IRQ
        HG_GMAC_REG_OPT(dev->hw->CSR7 = (HG_GMAC_CSR7_AIE_EN | HG_GMAC_CSR7_NIE_EN | HG_GMAC_CSR7_RIE_EN | HG_GMAC_CSR7_RUE_EN));

        dev->ctrl_data.rx_flag = 0;

        if (dev->ctrl_data.reset_flag) {
            /* If there is no tx, you can reset. */
            if (dev->ctrl_data.tx_flag == 0) {
                hg_gmac_bug_reset(ndev);
            }
        }
#else
        while (hg_gmac_has_received_frame(ndev) == RET_OK) {
            hg_gmac_receive_data(ndev);
        }
        /* 针对last descriptor先到，但是ru pending后到的情况，进行特殊处理。
         * 这种情况很可能在连续满带宽接收巨型帧的过程中出现。
         */
        hg_gmac_ru_handler(ndev);
        //clear pending
        HG_GMAC_REG_OPT(dev->hw->CSR5 = HG_GMAC_CSR5_RI_PENDING);
        //enable RI&RU IRQ
        HG_GMAC_REG_OPT(dev->hw->CSR7 = (HG_GMAC_CSR7_AIE_EN | HG_GMAC_CSR7_NIE_EN | HG_GMAC_CSR7_RIE_EN | HG_GMAC_CSR7_RUE_EN));
#endif
    }
}

#if HG_GMAC_FIX_BUG_RESET_EN
/* Check gmac for frame drop every 100ms. */
static void hg_gmac_check_thread(void *argument)
{
    struct netdev *ndev = (struct netdev *)argument;
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;
    uint32 csr_temp;

    while (1) {
        os_sleep_ms(100);

        if (dev->ctrl_data.reset_flag) {
            continue;
        }

        HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR5);

        if (!(csr_temp & HG_GMAC_CSR5_RU_PENDING)) {
            HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR8);
            if (csr_temp != dev->ctrl_data.miss_frame_cnt) {
                dev->ctrl_data.reset_flag = 1;
                dev->statistics.miss_err_cnt++;
                irq_disable(dev->irq_num);
                /* If there is no tx and rx, you can reset. */
                if ((dev->ctrl_data.tx_flag == 0) &&
                    (dev->ctrl_data.rx_flag == 0) &&
                    dev->ctrl_data.reset_flag) {
                    hg_gmac_bug_reset(ndev);
                }
            }
        }
    }
}
#endif

static void hg_gmac_statistics_printf(struct netdev *ndev)
{
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;

    gmac_dbg("gmac xfer:\r\n    tx:%d, rx:%d, err:%d, rx overflow:%d\r\n",
             dev->statistics.tx_cnt,
             dev->statistics.rx_cnt,
             dev->statistics.rx_err_cnt,
             dev->statistics.ru_pending_cnt);

#if HG_GMAC_FIX_BUG_RESET_EN
    gmac_dbg("gmac bug reset:\r\n    crc:%d, miss:%d, err:%d\r\n",
             dev->statistics.crc_err_cnt,
             dev->statistics.miss_err_cnt,
             dev->statistics.rx_err_reset_cnt);
#endif
}

static void hg_gmac_phy_link_change(void *dev)
{
    uint32 reg;
    uint32 csr_temp;
    struct ethernet_phy_device *phydev = (struct ethernet_phy_device *)dev;
    struct hg_gmac_eva *gmac           = (struct hg_gmac_eva *)phydev->ndev;

    if (phydev->link) {
        if ((phydev->last_speed != phydev->speed) || (phydev->last_duplex != phydev->duplex)) {

            /* Speed and duplex settings are only possible when the MAC
             * is in STOP.
             */
            phydev->last_speed  = 0;
            phydev->last_duplex = -1;

            HG_GMAC_REG_OPT(
                csr_temp  = gmac->hw->CSR6;
                csr_temp &= ~(HG_GMAC_CSR6_ST_EN | HG_GMAC_CSR6_SR_EN);
            );

            HG_GMAC_REG_OPT(gmac->hw->CSR6 = csr_temp);
            HG_GMAC_REG_OPT(csr_temp = gmac->hw->CSR5);

            /* Don't wait to stop */
            if (HG_GMAC_CSR5_TS_GET(csr_temp) || HG_GMAC_CSR5_RS_GET(csr_temp)) {
                return;
            }

            HG_GMAC_REG_OPT(reg = gmac->hw->CSR6);

            /* Clear speed and duplex settings */
            reg &= ~(HG_GMAC_CSR6_FD | HG_GMAC_CSR6_SPEED_MASK);

            if (phydev->duplex) {
                reg |= HG_GMAC_CSR6_FD;
            } else {
                reg &= ~HG_GMAC_CSR6_FD;
            }

            switch (phydev->speed) {
                case SPEED_10:
                    reg |= HG_GMAC_CSR6_SPEED_SET(HG_GMAC_ETHERNET_10M);
                    break;
                case SPEED_100:
                    reg |= HG_GMAC_CSR6_SPEED_SET(HG_GMAC_ETHERNET_100M);
                    break;
                case SPEED_1000:
                    reg |= HG_GMAC_CSR6_SPEED_SET(HG_GMAC_ETHERNET_1G);
                    break;
            }

            HG_GMAC_REG_OPT(gmac->hw->CSR6 = reg);

            /* Start the sending and receiving functions of the MAC */
            HG_GMAC_REG_OPT(
                csr_temp  = gmac->hw->CSR6;
                csr_temp |= HG_GMAC_CSR6_ST_EN | HG_GMAC_CSR6_SR_EN;
            );

            HG_GMAC_REG_OPT(gmac->hw->CSR6 = csr_temp);
            /* clear pending */
            HG_GMAC_REG_OPT(gmac->hw->CSR5 = (HG_GMAC_CSR5_TPS_PENDING | HG_GMAC_CSR5_RPS_PENDING | HG_GMAC_CSR5_RU_PENDING));

            phydev->last_speed  = phydev->speed;
            phydev->last_duplex = phydev->duplex;

            gmac->link_status   = LINK_OK;
            gmac->speed         = phydev->speed;
            gmac->duplex        = phydev->duplex;
            
            SYSEVT_NEW_NETWORK_EVT(SYSEVT_GMAC_LINK_UP, gmac->speed);
            gmac_dbg("***ethernet link up:%d %d\r\n", phydev->duplex, phydev->speed);
        }
    }

    if (phydev->link != phydev->last_link) {
        if (!phydev->link) {
            gmac_dbg("***ethernet link lost\r\n");

            gmac->link_status   = LINK_DOWN;
            gmac->speed         = 0;
            gmac->duplex        = -1;

            phydev->last_speed  = 0;
            phydev->last_duplex = -1;

            hg_gmac_statistics_printf(phydev->ndev);

            /* The MAC goes to the STOP state */
//            HG_GMAC_REG_OPT(
//                csr_temp  = gmac->hw->CSR6;
//                csr_temp &= ~(HG_GMAC_CSR6_ST_EN | HG_GMAC_CSR6_SR_EN);
//            );
//            HG_GMAC_REG_OPT(
//                gmac->hw->CSR6 = csr_temp;
//            );
//            /* Don't wait to stop */
//            HG_GMAC_REG_OPT(
//                csr_temp = gmac->hw->CSR5;
//            );
//            if(HG_GMAC_CSR5_TS_GET(csr_temp) || HG_GMAC_CSR5_RS_GET(csr_temp)) {
//                return;
//            }
            /* reset GMAC, then stop */
            hg_gmac_reset(phydev->ndev);
            SYSEVT_NEW_NETWORK_EVT(SYSEVT_GMAC_LINK_DOWN, 0);
        }
        phydev->last_link = phydev->link;
    }
}

static void hg_gmac_phy_event(void *phy, uint32 event, uint32 param1, uint32 param2)
{
    switch (event) {
        case NETDEV_PHY_EVENT_LINK_CHANGED:
            hg_gmac_phy_link_change(phy);
            break;
        default:
            break;
    }
}

/**
  * @brief  The MII management interface sends data
  * @param  emac_dev: GMAC module pointer
  * @param  phy_addr: phy address
  * @param  reg_addr: register address
  * @param  data    : Data to send
  * @retval None
  * @note   Data format symbol IEEE802.3 clause 22
  */
static void hg_gmac_mdio_write(struct netdev *ndev, uint16 phy_addr, uint16 reg_addr, uint16 data)
{
    uint32 i;
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;

    os_mutex_lock(&dev->mdio_mutex, osWaitForever);

    //preamble
    HG_GMAC_MDC_LOW(dev);
    HG_GMAC_MDIO_HIGH(dev);
    HG_GMAC_DELAY(dev);
    for (i = 0; i < 32; i++) {
        HG_GMAC_MDC_HIGH(dev);
        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_LOW(dev);
        HG_GMAC_DELAY(dev);
    }

    //ST
    HG_GMAC_MDIO_LOW(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);
    HG_GMAC_MDC_LOW(dev);

    HG_GMAC_MDIO_HIGH(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);
    HG_GMAC_MDC_LOW(dev);
    //OP
    HG_GMAC_MDIO_LOW(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);
    HG_GMAC_MDC_LOW(dev);

    HG_GMAC_MDIO_HIGH(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);
    HG_GMAC_MDC_LOW(dev);

    //PHYAD
    for (i = 0; i < 5; i++) {
        if (phy_addr & BIT(4 - i)) {
            HG_GMAC_MDIO_HIGH(dev);
        } else {
            HG_GMAC_MDIO_LOW(dev);
        }
        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_HIGH(dev);

        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_LOW(dev);
    }

    //REGAD
    for (i = 0; i < 5; i++) {
        if (reg_addr & BIT(4 - i)) {
            HG_GMAC_MDIO_HIGH(dev);
        } else {
            HG_GMAC_MDIO_LOW(dev);
        }
        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_HIGH(dev);

        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_LOW(dev);
    }

    //TA
    HG_GMAC_MDIO_HIGH(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);
    HG_GMAC_MDC_LOW(dev);

    HG_GMAC_MDIO_LOW(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);
    HG_GMAC_MDC_LOW(dev);

    //DATA
    for (i = 0; i < 16; i++) {
        if (data & BIT(15 - i)) {
            HG_GMAC_MDIO_HIGH(dev);
        } else {
            HG_GMAC_MDIO_LOW(dev);
        }
        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_HIGH(dev);

        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_LOW(dev);
    }

    /* Looks like I have to go through a few more IOs to ensure that the
     * data has been written in?
     */
    HG_GMAC_MDC_LOW(dev);
    HG_GMAC_MDIO_HIGH(dev);
    HG_GMAC_DELAY(dev);
    for (i = 0; i < 32; i++) {
        HG_GMAC_MDC_HIGH(dev);
        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_LOW(dev);
        HG_GMAC_DELAY(dev);
    }

    os_sleep_ms(1);

    os_mutex_unlock(&dev->mdio_mutex);
}

/**
  * @brief  The MII management interface receives data
  * @param  emac_dev: GMAC module pointer
  * @param  phy_addr: phy address
  * @param  reg_addr: register address
  * @retval Return the read data
  * @note   Data format symbol IEEE802.3 clause 22
  */
static int32 hg_gmac_mdio_read(struct netdev *ndev, uint16 phy_addr, uint16 reg_addr)
{
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;
    uint32 i;
    uint16 data = 0;

    os_mutex_lock(&dev->mdio_mutex, osWaitForever);

    //preamble
    HG_GMAC_MDC_LOW(dev);
    HG_GMAC_MDIO_HIGH(dev);
    HG_GMAC_DELAY(dev);
    for (i = 0; i < 32; i++) {
        HG_GMAC_MDC_HIGH(dev);
        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_LOW(dev);
        HG_GMAC_DELAY(dev);
    }

    //ST
    HG_GMAC_MDIO_LOW(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);
    HG_GMAC_MDC_LOW(dev);

    HG_GMAC_MDIO_HIGH(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);
    HG_GMAC_MDC_LOW(dev);
    //OP
    HG_GMAC_MDIO_HIGH(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);
    HG_GMAC_MDC_LOW(dev);

    HG_GMAC_MDIO_LOW(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);
    HG_GMAC_MDC_LOW(dev);

    //PHYAD
    for (i = 0; i < 5; i++) {
        if (phy_addr & BIT(4 - i)) {
            HG_GMAC_MDIO_HIGH(dev);
        } else {
            HG_GMAC_MDIO_LOW(dev);
        }
        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_HIGH(dev);

        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_LOW(dev);
    }

    //REGAD
    for (i = 0; i < 5; i++) {
        if (reg_addr & BIT(4 - i)) {
            HG_GMAC_MDIO_HIGH(dev);
        } else {
            HG_GMAC_MDIO_LOW(dev);
        }
        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_HIGH(dev);

        HG_GMAC_DELAY(dev);
        HG_GMAC_MDC_LOW(dev);
    }

    //TA
    HG_GMAC_MDIO_SET_INPUT(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDC_LOW(dev);
    HG_GMAC_DELAY(dev);

    /*ta = HG_GMAC_MDIO_GET(dev);*/
    HG_GMAC_MDC_HIGH(dev);
    HG_GMAC_DELAY(dev);

    //DATA
    for (i = 0; i < 16; i++) {
        HG_GMAC_MDC_LOW(dev);
        if (HG_GMAC_MDIO_GET(dev)) {
            data |= BIT(15 - i);
        }
        HG_GMAC_DELAY(dev);

        HG_GMAC_MDC_HIGH(dev);
        HG_GMAC_DELAY(dev);
    }

    //IDLE
    HG_GMAC_MDC_LOW(dev);
    HG_GMAC_DELAY(dev);

    HG_GMAC_MDIO_SET_OUTPUT(dev);
    HG_GMAC_MDIO_HIGH(dev);
    HG_GMAC_DELAY(dev);

    os_mutex_unlock(&dev->mdio_mutex);

    return data;
}

static void hg_gmac_hw_init(struct hg_gmac_eva_hw *p_gmac)
{
    /* GMAC clock selection */
    //enable gmac clock
    SYSCTRL_REG_OPT(sysctrl_gmac_clk_open());
    //gmac clock from io
    SYSCTRL_REG_OPT(sysctrl_gmac_clk_sel_clk_from_io());
    //gmac dma en
    SYSCTRL_REG_OPT(sysctrl_gmac_dma_enable());
    /* reset gmac */
    SYSCTRL_REG_OPT(sysctrl_gmac_sys_rst());

    //use software controllable
    //MDIO set to output. MDC&MDIO set low.
    HG_GMAC_REG_OPT(p_gmac->CSR9 = BIT(18));

    /* PBL cannot be 0, the recommended setting is 16 */
    /* disable transmit automatic polling */
    HG_GMAC_REG_OPT(p_gmac->CSR0 = (HG_GMAC_CSR0_TAP_SET(0) | HG_GMAC_CSR0_PBL_SET(HG_GMAC_PBL_16)));

    /* clear all pending */
    HG_GMAC_REG_OPT(p_gmac->CSR5 = 0x00004DE7);
    /* disable all interrupt */
    HG_GMAC_REG_OPT(p_gmac->CSR7 = 0x00000000);
}

static void hg_gmac_descriptor_init(struct hg_gmac_data *p_ctrl)
{
    uint32 i;
    /* initialization descriptor */
    os_memset(p_ctrl->p_rx_des_buf, 0, sizeof(struct hg_gmac_rx_descriptor) * p_ctrl->rx_des_num);
    os_memset(p_ctrl->p_tx_des_buf, 0, sizeof(struct hg_gmac_tx_descriptor) * p_ctrl->tx_des_num);
    /* rx descriptor */
    for (i = 0; i < p_ctrl->rx_des_num; i++) {
        p_ctrl->p_rx_des_buf[i].own                 = 1;
        /* use ring mode */
        p_ctrl->p_rx_des_buf[i].second_addr_chained = 0;
        p_ctrl->p_rx_des_buf[i].buf_1_size          = HG_GMAC_RX_PER_BUF_SIZE;
        p_ctrl->p_rx_des_buf[i].rx_buf_addr_1       = (uint32)&p_ctrl->p_rx_buf[i * HG_GMAC_RX_PER_BUF_SIZE];
        /* Point to the next descriptor */
        p_ctrl->p_rx_des_buf[i].p_next              = &p_ctrl->p_rx_des_buf[i + 1];
    }
    /* the last rx descriptor */
    p_ctrl->p_rx_des_buf[p_ctrl->rx_des_num - 1].buf_1_size     = HG_GMAC_RX_FRAME_MAX_SIZE;
    p_ctrl->p_rx_des_buf[p_ctrl->rx_des_num - 1].p_next         = &p_ctrl->p_rx_des_buf[0];
    /* The ring mode requires the end_of_ring to be set in the last descriptor */
    p_ctrl->p_rx_des_buf[p_ctrl->rx_des_num - 1].end_of_ring    = 1;

    /* tx descriptor */
    for (i = 0; i < p_ctrl->tx_des_num; i++) {
        p_ctrl->p_tx_des_buf[i].own                 = 0;
        /*! The hardware module is limited, and one frame can only correspond to one
         *  descriptor.
         */
        p_ctrl->p_tx_des_buf[i].first_descriptor    = 1;
        p_ctrl->p_tx_des_buf[i].last_descriptor     = 1;
        /* use ring mode */
        p_ctrl->p_tx_des_buf[i].second_addr_chained = 0;
        p_ctrl->p_tx_des_buf[i].tx_buf_addr_1       = (uint32)&p_ctrl->p_tx_buf[i * HG_GMAC_TX_PER_BUF_SIZE];
        /* Point to the next descriptor */
        p_ctrl->p_tx_des_buf[i].p_next              = &p_ctrl->p_tx_des_buf[i + 1];
    }
    p_ctrl->p_tx_des_buf[p_ctrl->tx_des_num - 1].p_next      = &p_ctrl->p_tx_des_buf[0];
    /* The ring mode requires the end_of_ring to be set in the last descriptor */
    p_ctrl->p_tx_des_buf[p_ctrl->tx_des_num - 1].end_of_ring = 1;
}

static int32 hg_gmac_send_data(struct netdev *ndev, uint8 *p_data, uint32 size)
{
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;
    uint32 csr_temp;

    if (size > 1514) {
        return RET_ERR;
    }

    //no link?
    if (dev->link_status != LINK_OK) {
        return RET_ERR;
    }

    //no need to send
    if (size == 0) {
        return RET_OK;
    }

    //Wait for the free descriptor to be released
    while (dev->ctrl_data.p_tx_des->own) {
        //tx stop?
        HG_GMAC_REG_OPT(csr_temp  = dev->hw->CSR6);
        if (!(csr_temp & HG_GMAC_CSR6_ST_EN)) {
            return RET_ERR;
        }
        //csi_kernel_task_yield();
    }

#if HG_GMAC_FIX_BUG_RESET_EN
    dev->ctrl_data.tx_flag = 1;
    if (dev->ctrl_data.reset_flag) {
        dev->ctrl_data.tx_flag = 0;
        /* If there is no rx, you can reset. */
        if (dev->ctrl_data.rx_flag == 0) {
            hg_gmac_bug_reset(ndev);
        }
        return RET_ERR;
    }

    /* If there is frame loss but no RU pending, there must be a bug. */
    HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR8);
    if (csr_temp != dev->ctrl_data.miss_frame_cnt) {
        HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR5);
        if (!(csr_temp & HG_GMAC_CSR5_RU_PENDING)) {
            dev->ctrl_data.reset_flag = 1;
            dev->statistics.miss_err_cnt++;
            irq_disable(dev->irq_num);
            /* If there is no rx, you can reset. */
            dev->ctrl_data.tx_flag = 0;
            if (dev->ctrl_data.rx_flag == 0) {
                hg_gmac_bug_reset(ndev);
            }
            return RET_ERR;
        }
    }
#endif

    /* Recovery descriptor */
    if (dev->ctrl_data.p_tx_des->setup_packet) {
        dev->ctrl_data.p_tx_des->setup_packet         = 0;
        dev->ctrl_data.p_tx_des->filtering_type_1     = 0;
        dev->ctrl_data.p_tx_des->filtering_type_0     = 0;
        dev->ctrl_data.p_tx_des->first_descriptor     = 1;
        dev->ctrl_data.p_tx_des->last_descriptor      = 1;
    }

    hw_memcpy((void *)dev->ctrl_data.p_tx_des->tx_buf_addr_1, p_data, size);

    dev->ctrl_data.p_tx_des->buf_1_size        = size;
    dev->ctrl_data.p_tx_des->int_on_completion = 1;
    dev->ctrl_data.p_tx_des->own               = 1;
    /* The descriptor automatically points to the next descriptor */
    dev->ctrl_data.p_tx_des = dev->ctrl_data.p_tx_des->p_next;

    /* kick tx start */
    //HG_GMAC_REG_OPT (dev->hw->CSR5 = HG_GMAC_CSR5_TU_PENDING | HG_GMAC_CSR5_UNF_PENDING);
    HG_GMAC_REG_OPT(dev->hw->CSR1 = 0x00;);

    dev->statistics.tx_cnt++;

#if HG_GMAC_FIX_BUG_RESET_EN
    if (dev->ctrl_data.reset_flag) {
        /* If there is no rx, you can reset. */
        if (dev->ctrl_data.rx_flag == 0) {
            hg_gmac_bug_reset(ndev);
        }
    }
    dev->ctrl_data.tx_flag = 0;
#endif

    return RET_OK;
}

//Send segmented Ethernet frames
static int32 hg_gmac_send_scatter_data(struct netdev *ndev, scatter_data *p_data, uint32 count)
{
    uint32 len = 0;
    uint32 addr;
    uint32 csr_temp;
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;

    addr = dev->ctrl_data.p_tx_des->tx_buf_addr_1;
    //no link?
    if (dev->link_status != LINK_OK) {
        return RET_ERR;
    }
    //no need to send
    if (count == 0) {
        return RET_OK;
    }

    //Wait for the free descriptor to be released
    while (dev->ctrl_data.p_tx_des->own) {
        //tx stop?
        HG_GMAC_REG_OPT(csr_temp  = dev->hw->CSR6);
        if (!(csr_temp & HG_GMAC_CSR6_ST_EN)) {
            return RET_ERR;
        }
        //csi_kernel_task_yield();
    }

#if HG_GMAC_FIX_BUG_RESET_EN
    dev->ctrl_data.tx_flag = 1;
    if (dev->ctrl_data.reset_flag) {
        dev->ctrl_data.tx_flag = 0;
        /* If there is no rx, you can reset. */
        if (dev->ctrl_data.rx_flag == 0) {
            hg_gmac_bug_reset(ndev);
        }
        return RET_ERR;
    }

    /* If there is frame loss but no RU pending, there must be a bug. */
    HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR8);
    if (csr_temp != dev->ctrl_data.miss_frame_cnt) {
        HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR5);
        if (!(csr_temp & HG_GMAC_CSR5_RU_PENDING)) {
            dev->ctrl_data.reset_flag = 1;
            dev->statistics.miss_err_cnt++;
            irq_disable(dev->irq_num);
            /* If there is no tx, you can reset. */
            dev->ctrl_data.tx_flag = 0;
            if (dev->ctrl_data.rx_flag == 0) {
                hg_gmac_bug_reset(ndev);
            }
            return RET_ERR;
        }
    }
#endif

    /* Recovery descriptor */
    if (dev->ctrl_data.p_tx_des->setup_packet) {
        dev->ctrl_data.p_tx_des->setup_packet         = 0;
        dev->ctrl_data.p_tx_des->filtering_type_1     = 0;
        dev->ctrl_data.p_tx_des->filtering_type_0     = 0;
        dev->ctrl_data.p_tx_des->first_descriptor     = 1;
        dev->ctrl_data.p_tx_des->last_descriptor      = 1;
    }

    while (count--) {
        len += p_data->size;
        if (len > 1514) {
#if HG_GMAC_FIX_BUG_RESET_EN
            dev->ctrl_data.tx_flag = 0;
#endif
            return RET_ERR;
        }
        hw_memcpy((void *)addr, (void *)p_data->addr, p_data->size);
        addr += p_data->size;
        p_data++;
    }

    //no need to send
    if (len == 0) {
        return RET_OK;
    }

    dev->ctrl_data.p_tx_des->buf_1_size        = len;
    dev->ctrl_data.p_tx_des->int_on_completion = 1;
    dev->ctrl_data.p_tx_des->own               = 1;
    /* The descriptor automatically points to the next descriptor */
    dev->ctrl_data.p_tx_des = dev->ctrl_data.p_tx_des->p_next;

    /* kick tx start */
    // HG_GMAC_REG_OPT (dev->hw->CSR5 = HG_GMAC_CSR5_TU_PENDING | HG_GMAC_CSR5_UNF_PENDING);
    HG_GMAC_REG_OPT(dev->hw->CSR1 = 0x00;);

    dev->statistics.tx_cnt++;

#if HG_GMAC_FIX_BUG_RESET_EN
    if (dev->ctrl_data.reset_flag) {
        /* If there is no rx, you can reset. */
        if (dev->ctrl_data.rx_flag == 0) {
            hg_gmac_bug_reset(ndev);
        }
    }
    dev->ctrl_data.tx_flag = 0;
#endif

    return RET_OK;
}

int32 hg_gmac_has_received_frame(struct netdev *ndev)
{
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;
    struct hg_gmac_rx_descriptor *p_rx = (void *)dev->ctrl_data.p_rx_des;

    while (1) {
        if (p_rx->own) {
            return RET_ERR;
        } else if (p_rx->last_descriptor) {
            return RET_OK;
        }
        p_rx = p_rx->p_next;
    }
}

int32 hg_gmac_receive_data(struct netdev *ndev)
{
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;
    struct hg_gmac_rx_descriptor *p_rx, *p_rx_start;
#if HG_GMAC_FIX_BUG_RESET_EN
    uint32 temp, crc;
    struct crc_dev_req req;
#endif
    uint32 flags;
    netdev_input_cb input_cb;
    void *input_priv;

    p_rx = p_rx_start = (void *)dev->ctrl_data.p_rx_des;
    dev->statistics.rx_cnt++;

    /* Find the last descriptor */
    while (1) {
        if (p_rx->last_descriptor) {
            break;
        }
        p_rx = p_rx->p_next;
        /* As long as the start of the start descriptor is not released,
         * there will be no problem.
         */
        p_rx->own = 1;
    }
    
    flags = disable_irq();
    input_cb = dev->input_cb;
    input_priv = dev->input_priv;
    enable_irq(flags);

#if HG_GMAC_FIX_BUG_RESET_EN
    /* The frame can be copied without error and no truncation */
    if (!p_rx->err_summary) {
        /* Start the crc calculation. */
        req.type  = CRC_TYPE_CRC32_WINRAR;
        req.data  = p_rx_start->rx_buf_addr_1;
        req.len   = p_rx->frame_len - 4;
        /* Save the CRC result of GMAC rx. */
        memcpy(&temp, (void *)(p_rx_start->rx_buf_addr_1 + p_rx->frame_len - 4), 4);
        if(input_cb){
            input_cb(ndev, (void *)p_rx_start->rx_buf_addr_1, p_rx->frame_len - 4, input_priv);
        }

        /* Check whether the CRC result of GMAC rx is consistent with the actual calculation. */
		if (RET_ERR == crc_dev_calc(dev->crcdev, &req, &crc, 0)) {
			return RET_ERR;
		}		
        if (crc && temp != crc) {
            /** There is an error in receiving, it is probably a bug. **/
            /* disalbe IRQ */
            irq_disable(dev->irq_num);
            /* need to reset */
            dev->ctrl_data.reset_flag = 1;
            dev->statistics.crc_err_cnt++;
        }
    } else {
        /* Check RU pending. */
        HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR5);
        /* If RU appears, it means there is no need to clear the data. */
        if (!(csr_temp & HG_GMAC_CSR5_RU_PENDING)) {
            /* Turn off the CRS_DV first. */
            gmac_csr_dv_disable(ndev->dev.dev_id);

            HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR6);

            if ((csr_temp & 0x00020000) == 0x00020000) {
                os_sleep_us(5);     //for 10Mbps, SYS_CLK = 48M
            } else {
                os_sleep_us(1);     //for 100Mbps, SYS_CLK = 48M
            }

            HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR5);
            /* check GMAC rx state */
            if ((csr_temp & 0x000E0000) == 0x000E0000) {
                /* disalbe IRQ */
                irq_disable(dev->irq_num);
                /* need to reset */
                dev->ctrl_data.reset_flag = 1;
                dev->statistics.rx_err_reset_cnt++;
            }
            /* Finally resume the CSR_DV function */
            gmac_csr_dv_enable(ndev->dev.dev_id);
        }
    }
#else
    /* The frame can be copied without error and no truncation */
    if (!p_rx->err_summary && input_cb) {
        input_cb(ndev, (void *)p_rx_start->rx_buf_addr_1, p_rx->frame_len - 4, input_priv);
    }
#endif

    /* Release descriptor */
    p_rx_start->own = 1;
    /* The descriptor automatically points to the next descriptor */
    dev->ctrl_data.p_rx_des = p_rx->p_next;
    /* Process RU pending normally. */
    hg_gmac_ru_handler(ndev);
    return RET_OK;
}

static int32 hg_gmac_set_mac_addr(struct netdev *ndev, uint8 *addr)
{
    /***** setup frame send *****/
    struct hg_gmac_setup_perfect_filter *p_filter = NULL;
    uint32 i, csr_temp;
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;

    /* The hardware is turned off, save the MAC address first and
     * reconfigure it when open.
     */
    if(dev->opened == 0) {
        /* save mac addr */
        os_memcpy(dev->mac_addr, addr, 6);
        return RET_OK;
    }

    p_filter = (struct hg_gmac_setup_perfect_filter *)dev->ctrl_data.p_tx_des->tx_buf_addr_1;
    //Wait for the free descriptor to be released
    while (dev->ctrl_data.p_tx_des->own) {
        //tx stop?
        HG_GMAC_REG_OPT(csr_temp  = dev->hw->CSR6);

        if (!(csr_temp & HG_GMAC_CSR6_ST_EN)) {
            return RET_ERR;
        }
        //csi_kernel_task_yield();
    }

    /* save mac addr */
    os_memcpy(dev->mac_addr, addr, 6);

#if HG_GMAC_FIX_BUG_RESET_EN
    dev->ctrl_data.tx_flag = 1;
    if (dev->ctrl_data.reset_flag) {
        dev->ctrl_data.tx_flag = 0;
        /* If there is no rx, you can reset. */
        if (dev->ctrl_data.rx_flag == 0) {
            hg_gmac_bug_reset(ndev);
        }
        return RET_ERR;
    }

    /* If there is frame loss but no RU pending, there must be a bug. */
    HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR8);

    if (csr_temp != dev->ctrl_data.miss_frame_cnt) {
        HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR5);
        if (!(csr_temp & HG_GMAC_CSR5_RU_PENDING)) {
            dev->ctrl_data.reset_flag = 1;
            dev->statistics.miss_err_cnt++;
            irq_disable(dev->irq_num);
            /* If there is no rx, you can reset. */
            dev->ctrl_data.tx_flag = 0;
            if (dev->ctrl_data.rx_flag == 0) {
                hg_gmac_bug_reset(ndev);
            }
            return RET_ERR;
        }
    }
#endif

    /* Set the whitelist MAC address */
    p_filter->mac_addr[0].addr_15_00 = (addr[1] << 8) | addr[0];
    p_filter->mac_addr[0].addr_31_16 = (addr[3] << 8) | addr[2];
    p_filter->mac_addr[0].addr_47_32 = (addr[5] << 8) | addr[4];
    /* Fill the remaining space with the first MAC address */
    for (i = 1; i < sizeof(p_filter->mac_addr) / sizeof(p_filter->mac_addr[0]); i++) {
        os_memcpy(&p_filter->mac_addr[i], &p_filter->mac_addr[0], sizeof(p_filter->mac_addr[0]));
    }

    /* interrupt on completion */
    dev->ctrl_data.p_tx_des->int_on_completion = 1;
    /* clear first&last descriptor */
    dev->ctrl_data.p_tx_des->first_descriptor  = 0;
    dev->ctrl_data.p_tx_des->last_descriptor   = 0;

    /* configurate destination address filter mode(PERFECT_FILTER) */
    dev->ctrl_data.p_tx_des->filtering_type_1  = 0;
    dev->ctrl_data.p_tx_des->filtering_type_0  = 0;

    /* setup packet */
    dev->ctrl_data.p_tx_des->setup_packet      = 1;
    /* size = 192byte */
    dev->ctrl_data.p_tx_des->buf_1_size        = 192;
    dev->ctrl_data.p_tx_des->own               = 1;

    dev->ctrl_data.p_tx_des = dev->ctrl_data.p_tx_des->p_next;

#if HG_GMAC_FIX_BUG_RESET_EN
    if (dev->ctrl_data.reset_flag && dev->ctrl_data.rx_flag == 0) {
        /* If there is no rx, you can reset. */
        hg_gmac_bug_reset(ndev);
    }
    dev->ctrl_data.tx_flag = 0;
#endif
    return RET_OK;
}

static int32 hg_gmac_force_link(struct netdev *ndev, uint32 link_speed, uint32 duplex_flag)
{
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;
    uint32 csr_temp, reg;

    if (dev->opened == 0) {
        return RET_ERR;
    }

    if ((link_speed != SPEED_10) && (link_speed != SPEED_100)) {
        return RET_ERR;
    }

    HG_GMAC_REG_OPT(
        csr_temp  = dev->hw->CSR6;
        csr_temp &= ~(HG_GMAC_CSR6_ST_EN | HG_GMAC_CSR6_SR_EN);
    );

    HG_GMAC_REG_OPT(dev->hw->CSR6 = csr_temp;);

    /* wait to stop */
    do {
        HG_GMAC_REG_OPT(csr_temp = dev->hw->CSR5);
    } while (HG_GMAC_CSR5_TS_GET(csr_temp) || HG_GMAC_CSR5_RS_GET(csr_temp));

    HG_GMAC_REG_OPT(reg = dev->hw->CSR6);
    /* Clear speed and duplex settings */
    reg &= ~(HG_GMAC_CSR6_FD | HG_GMAC_CSR6_SPEED_MASK);

    if (duplex_flag) {
        reg |= HG_GMAC_CSR6_FD;
    } else {
        reg &= ~HG_GMAC_CSR6_FD;
    }

    switch (link_speed) {
        case SPEED_10:
            reg |= HG_GMAC_CSR6_SPEED_SET(HG_GMAC_ETHERNET_10M);
            break;
        case SPEED_100:
            reg |= HG_GMAC_CSR6_SPEED_SET(HG_GMAC_ETHERNET_100M);
            break;
        default:
            return RET_ERR;
    }

    /* Start the sending and receiving functions of the MAC */
    HG_GMAC_REG_OPT(
        csr_temp  = dev->hw->CSR6;
        csr_temp |= HG_GMAC_CSR6_ST_EN | HG_GMAC_CSR6_SR_EN;
    );

    HG_GMAC_REG_OPT(dev->hw->CSR6 = csr_temp);

    /* clear pending */
    HG_GMAC_REG_OPT(dev->hw->CSR5 = (HG_GMAC_CSR5_TPS_PENDING | HG_GMAC_CSR5_RPS_PENDING | HG_GMAC_CSR5_RU_PENDING));

    dev->speed       = link_speed;
    dev->link_status = LINK_OK;

    SYSEVT_NEW_NETWORK_EVT(SYSEVT_GMAC_LINK_UP, link_speed);
    return RET_OK;
}

__init static int32 hg_gmac_open(struct netdev *ndev, netdev_input_cb input_cb, netdev_event_cb evt_cb, void *priv)
{
    struct hg_gmac_setup_perfect_filter *p_filter = NULL;
    struct ethernet_phy_device *phydev   = NULL;
    struct ethernet_mdio_bus   *mdio_bus = NULL;
    struct hg_gmac_eva *dev = (struct hg_gmac_eva *)ndev;
    const uint8 default_mac_addr[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,};
    int32 ret = 0;

    if (dev->opened) {
        goto _DONE;
    }

    /* +7 for 8byte alignment */
    if (dev->tx_buf_size < HG_GMAC_TX_MIN_BUF_SIZE + 7) {
        ASSERT(dev->tx_buf_size >= HG_GMAC_TX_MIN_BUF_SIZE + 7);
        return RET_ERR;
    }

    /* +7 for 8byte alignment. The number of rx descriptors must be greater than 2. */
    if (dev->rx_buf_size < HG_GMAC_RX_MIN_BUF_SIZE + 7) {
        ASSERT(dev->rx_buf_size >= HG_GMAC_RX_MIN_BUF_SIZE + 7);
    }

    dev->ctrl_data.tx_des_num  = (dev->tx_buf_size - 7) / (sizeof(struct hg_gmac_descriptor) + HG_GMAC_TX_PER_BUF_SIZE);
    dev->ctrl_data.rx_des_num  = (dev->rx_buf_size - 7 - (HG_GMAC_RX_FRAME_MAX_SIZE - HG_GMAC_RX_PER_BUF_SIZE)) /
                                 (sizeof(struct hg_gmac_descriptor) + HG_GMAC_RX_PER_BUF_SIZE);

    /* Apply for tx buffer. */
    dev->ctrl_data.p_tx_malloc = (uint8 *)os_malloc(dev->ctrl_data.tx_des_num * (sizeof(struct hg_gmac_descriptor) + HG_GMAC_TX_PER_BUF_SIZE) + 7);
    if (dev->ctrl_data.p_tx_malloc == NULL) {
        return RET_ERR;
    } else {
        dev->ctrl_data.p_tx_des_buf = (struct hg_gmac_tx_descriptor *)(((uint32)dev->ctrl_data.p_tx_malloc + 7) & ~0x07);
        dev->ctrl_data.p_tx_buf     = (uint8 *)(dev->ctrl_data.p_tx_des_buf + dev->ctrl_data.tx_des_num);
    }
    /* Apply for rx buffer. */
    dev->ctrl_data.p_rx_malloc = (uint8 *)os_malloc(dev->ctrl_data.rx_des_num * (sizeof(struct hg_gmac_descriptor) + HG_GMAC_RX_PER_BUF_SIZE) +
                                 (HG_GMAC_RX_FRAME_MAX_SIZE - HG_GMAC_RX_PER_BUF_SIZE) + 7);
    if (dev->ctrl_data.p_rx_malloc == NULL) {
        os_free(dev->ctrl_data.p_tx_malloc);
        return RET_ERR;
    } else {
        dev->ctrl_data.p_rx_des_buf = (struct hg_gmac_rx_descriptor *)(((uint32)dev->ctrl_data.p_rx_malloc + 7) & ~0x07);
        dev->ctrl_data.p_rx_buf     = (uint8 *)(dev->ctrl_data.p_rx_des_buf + dev->ctrl_data.rx_des_num);
    }

    ret = pin_func(ndev->dev.dev_id, 1);
    if (ret) {
        os_free(dev->ctrl_data.p_tx_malloc);
        os_free(dev->ctrl_data.p_rx_malloc);
        return ret;
    }

    /* enable the gamc module clk to config the regeister */
    hg_gmac_hw_init(dev->hw);

#if HG_GMAC_FIX_BUG_RESET_EN
    /* GMAC bug check thread */
    OS_TASK_INIT("GMAC check", &dev->check_task, hg_gmac_check_thread, (uint32)ndev, OS_TASK_PRIORITY_BELOW_NORMAL, 256);
#endif

    //Descriptor initialization
    hg_gmac_descriptor_init(&dev->ctrl_data);

    //config
    HG_GMAC_REG_OPT(dev->hw->CSR3 = (uint32)dev->ctrl_data.p_rx_des_buf);
    HG_GMAC_REG_OPT(dev->hw->CSR4 = (uint32)dev->ctrl_data.p_tx_des_buf);

    /* Save the starting descriptor pointer */
    dev->ctrl_data.p_rx_des = dev->ctrl_data.p_rx_des_buf;
    dev->ctrl_data.p_tx_des = dev->ctrl_data.p_tx_des_buf;

    HG_GMAC_REG_OPT(dev->hw->CSR6 = HG_GMAC_CSR6_PM_EN);    //Pass all multicast

    /***** setup frame send *****/
    /* Address filtering uses blacklist mode */
    p_filter = (struct hg_gmac_setup_perfect_filter *)dev->ctrl_data.p_tx_des->tx_buf_addr_1;
    os_memset(p_filter->mac_addr, 0xFF, sizeof(p_filter->mac_addr));

    /* interrupt on completion */
    dev->ctrl_data.p_tx_des->int_on_completion = 1;
    /* clear first&last descriptor */
    dev->ctrl_data.p_tx_des->first_descriptor  = 0;
    dev->ctrl_data.p_tx_des->last_descriptor   = 0;

    /* configurate destination address filter mode(INVERSE_FILTER) */
    dev->ctrl_data.p_tx_des->filtering_type_1  = 1;
    dev->ctrl_data.p_tx_des->filtering_type_0  = 0;

    /* setup packet */
    dev->ctrl_data.p_tx_des->setup_packet      = 1;
    /* size = 192byte */
    dev->ctrl_data.p_tx_des->buf_1_size        = 192;
    dev->ctrl_data.p_tx_des->own               = 1;

    dev->ctrl_data.p_tx_des = dev->ctrl_data.p_tx_des->p_next;
    /***** setup frame send end *****/

    /* RI interrupt enable */
    HG_GMAC_REG_OPT(dev->hw->CSR7 = (HG_GMAC_CSR7_AIE_EN | HG_GMAC_CSR7_NIE_EN | HG_GMAC_CSR7_RIE_EN | HG_GMAC_CSR7_RUE_EN));

    if (dev->modbus_devid) {
        mdio_bus = (struct ethernet_mdio_bus *)dev_get(dev->modbus_devid);
        ASSERT(mdio_bus);
        ret = eth_mdio_bus_open(mdio_bus, ndev);
        ASSERT(!ret);
    }

    if (dev->phy_devid) {
        phydev = (struct ethernet_phy_device *)dev_get(dev->phy_devid);
        ASSERT(phydev);
        ret = eth_phy_open(phydev, mdio_bus, ndev);
        ASSERT(!ret);
    }

    if (dev->crc_devid) {
        dev->crcdev = (struct crc_dev *)dev_get(dev->crc_devid);
    }

    ret = request_irq(dev->irq_num, hg_gmac_irq_handler, dev);
    if (ret != RET_OK) {
        os_free(dev->ctrl_data.p_tx_malloc);
        os_free(dev->ctrl_data.p_rx_malloc);
        return ret;
    }

    irq_enable(dev->irq_num);
    dev->opened = 1;
    
    /***** setup frame send *****/
    /* If the MAC address is not the default value, we need to configure
     * the mac address.
     */
    if(os_memcmp(dev->mac_addr, default_mac_addr, 6)) {
        hg_gmac_set_mac_addr(ndev, dev->mac_addr);
    }
    /***** setup frame send end *****/
_DONE:
    if(input_cb){
        ret = disable_irq();
        dev->input_cb   = input_cb;
        dev->input_priv = priv;
        enable_irq(ret);
    }
    return RET_OK;
}

__init static int32 hg_gmac_close(struct netdev *ndev)
{
    struct hg_gmac_eva *gmac = (struct hg_gmac_eva *)ndev;
    struct ethernet_mdio_bus   *mdio_bus  = NULL;
    struct ethernet_phy_device *phydev    = NULL;
    int32 ret;

    if (!gmac->opened) {
        return RET_OK;
    }

    /* close the eth_phy os_work firstly , ensuring the mdio bus is idle */
    if (gmac->phy_devid) {
        phydev = (struct ethernet_phy_device *)dev_get(gmac->phy_devid);
        ASSERT(phydev);
        eth_phy_close(phydev);
    }

    /* close the mdio bus after closing eth_phy os_work */
    if (gmac->modbus_devid) {
        mdio_bus = (struct ethernet_mdio_bus *)dev_get(gmac->modbus_devid);
        ASSERT(mdio_bus);
        ret = eth_mdio_bus_close(mdio_bus);
        ASSERT(!ret);
    }

    irq_disable(gmac->irq_num);

    HG_GMAC_REG_OPT(gmac->hw->CSR6 = 0x00000000);

    while (HG_GMAC_CSR5_TS_GET(gmac->hw->CSR5)) {
        __NOP();
    }
    __NOP();
    while (HG_GMAC_CSR5_RS_GET(gmac->hw->CSR6)) {
        __NOP();
    }
    __NOP();

    SYSCTRL_REG_OPT(SYSCTRL->SYS_CON1 &= ~BIT(29));
    os_sleep_us(1);
    SYSCTRL_REG_OPT(SYSCTRL->SYS_CON1 |= BIT(29));
    os_sleep_us(1);

    /* free malloc */
    os_free(gmac->ctrl_data.p_rx_malloc);
    os_free(gmac->ctrl_data.p_tx_malloc);

    gmac->opened = 0;
    pin_func(ndev->dev.dev_id, 0);

    SYSCTRL_REG_OPT(sysctrl_gmac_clk_close());
    return RET_OK;
}

static int32 hg_gmac_ioctl(struct netdev *ndev, uint32 cmd, uint32 param1, uint32 param2)
{
    int32 ret = -ENOTSUPP;
    struct hg_gmac_eva *gmac = (struct hg_gmac_eva *)ndev;

    switch (cmd) {
        case NETDEV_IOCTL_GET_ADDR:
            os_memcpy((uint8 *)param1, gmac->mac_addr, 6);
            ret = RET_OK;
            break;
        case NETDEV_IOCTL_SET_ADDR:
            ret = hg_gmac_set_mac_addr(ndev, (uint8 *)param1);
            break;
        case NETDEV_IOCTL_GET_LINK_SPEED:
            ret = gmac->speed;
            break;
        case NETDEV_IOCTL_GET_LINK_STATUS:
            ret = gmac->link_status;
            break;
        case NETDEV_IOCTL_FORCE_LINK:
            ret = hg_gmac_force_link(ndev, param1, param2);
            break;
        default:
            break;
    }
    return ret;
}

/* GMAC reset */
void hg_gmac_reset(struct netdev *ndev)
{
    struct hg_gmac_setup_perfect_filter *p_filter = NULL;
    struct hg_gmac_eva *gmac = (struct hg_gmac_eva *)ndev;
    const uint8 default_addr[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    uint32 csr_temp;

    /* Turn off the CRS_DV first. */
    gmac_csr_dv_disable(ndev->dev.dev_id);

    HG_GMAC_REG_OPT(csr_temp = gmac->hw->CSR6);

    if ((csr_temp & 0x00020000) == 0x00020000) {
        os_sleep_us(5);     //for 10Mbps, SYS_CLK = 48M
    } else {
        os_sleep_us(1);     //for 100Mbps, SYS_CLK = 48M
    }

    /* disable irq */
    irq_disable(gmac->irq_num);
    /* reset gmac */
    hg_gmac_hw_init(gmac->hw);
    //Descriptor initialization
    hg_gmac_descriptor_init(&gmac->ctrl_data);
    //config
    HG_GMAC_REG_OPT(gmac->hw->CSR3 = (uint32)gmac->ctrl_data.p_rx_des_buf);
    HG_GMAC_REG_OPT(gmac->hw->CSR4 = (uint32)gmac->ctrl_data.p_tx_des_buf);
    /* Save the starting descriptor pointer */
    gmac->ctrl_data.p_rx_des = gmac->ctrl_data.p_rx_des_buf;
    gmac->ctrl_data.p_tx_des = gmac->ctrl_data.p_tx_des_buf;
    HG_GMAC_REG_OPT(gmac->hw->CSR6 = HG_GMAC_CSR6_PM_EN);  //Pass all multicast

    /* mac addr fileter */
    if (memcmp(gmac->mac_addr, default_addr, 6) == 0) {
        p_filter = (struct hg_gmac_setup_perfect_filter *)gmac->ctrl_data.p_tx_des->tx_buf_addr_1;
        os_memset(p_filter->mac_addr, 0xFF, sizeof(p_filter->mac_addr));
        /* interrupt on completion */
        gmac->ctrl_data.p_tx_des->int_on_completion = 1;
        /* clear first&last descriptor */
        gmac->ctrl_data.p_tx_des->first_descriptor  = 0;
        gmac->ctrl_data.p_tx_des->last_descriptor   = 0;
        /* configurate destination address filter mode(INVERSE_FILTER) */
        gmac->ctrl_data.p_tx_des->filtering_type_1  = 1;
        gmac->ctrl_data.p_tx_des->filtering_type_0  = 0;
        /* setup packet */
        gmac->ctrl_data.p_tx_des->setup_packet      = 1;
        /* size = 192byte */
        gmac->ctrl_data.p_tx_des->buf_1_size        = 192;
        gmac->ctrl_data.p_tx_des->own               = 1;
        gmac->ctrl_data.p_tx_des = gmac->ctrl_data.p_tx_des->p_next;
    } else {
        hg_gmac_set_mac_addr(ndev, gmac->mac_addr);
    }

    /* RI interrupt enable */
    HG_GMAC_REG_OPT(gmac->hw->CSR7 = (HG_GMAC_CSR7_AIE_EN | HG_GMAC_CSR7_NIE_EN | HG_GMAC_CSR7_RIE_EN | HG_GMAC_CSR7_RUE_EN));

    irq_enable(gmac->irq_num);
    /* Finally resume the CSR_DV function */
    gmac_csr_dv_enable(ndev->dev.dev_id);
}

#if HG_GMAC_FIX_BUG_RESET_EN
/* GMAC reset is only used when there is a bug. */
void hg_gmac_bug_reset(struct netdev *ndev)
{
    struct hg_gmac_setup_perfect_filter *p_filter = NULL;
    struct hg_gmac_eva *gmac = (struct hg_gmac_eva *)ndev;
    const uint8 default_addr[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    uint32 csr_temp;

    gmac->ctrl_data.reset_flag = 1;
    /* save CSR6 */
    HG_GMAC_REG_OPT(csr_temp = gmac->hw->CSR6);

    /* disable irq */
    irq_disable(gmac->irq_num);

    /* reset gmac */
    hg_gmac_hw_init(gmac->hw);

    //Descriptor initialization
    hg_gmac_descriptor_init(&gmac->ctrl_data);

    //config
    HG_GMAC_REG_OPT(gmac->hw->CSR3 = (uint32)gmac->ctrl_data.p_rx_des_buf);
    HG_GMAC_REG_OPT(gmac->hw->CSR4 = (uint32)gmac->ctrl_data.p_tx_des_buf);

    /* Save the starting descriptor pointer */
    gmac->ctrl_data.p_rx_des = gmac->ctrl_data.p_rx_des_buf;
    gmac->ctrl_data.p_tx_des = gmac->ctrl_data.p_tx_des_buf;

    HG_GMAC_REG_OPT(gmac->hw->CSR6 = HG_GMAC_CSR6_PM_EN);//Pass all multicast

    /* mac addr fileter */
    if (memcmp(gmac->mac_addr, default_addr, 6) == 0) {
        p_filter = (struct hg_gmac_setup_perfect_filter *)gmac->ctrl_data.p_tx_des->tx_buf_addr_1;
        os_memset(p_filter->mac_addr, 0xFF, sizeof(p_filter->mac_addr));
        /* interrupt on completion */
        gmac->ctrl_data.p_tx_des->int_on_completion = 1;
        /* clear first&last descriptor */
        gmac->ctrl_data.p_tx_des->first_descriptor  = 0;
        gmac->ctrl_data.p_tx_des->last_descriptor   = 0;
        /* configurate destination address filter mode(INVERSE_FILTER) */
        gmac->ctrl_data.p_tx_des->filtering_type_1  = 1;
        gmac->ctrl_data.p_tx_des->filtering_type_0  = 0;
        /* setup packet */
        gmac->ctrl_data.p_tx_des->setup_packet      = 1;
        /* size = 192byte */
        gmac->ctrl_data.p_tx_des->buf_1_size        = 192;
        gmac->ctrl_data.p_tx_des->own               = 1;
        gmac->ctrl_data.p_tx_des = gmac->ctrl_data.p_tx_des->p_next;
    } else {
        hg_gmac_set_mac_addr(ndev, gmac->mac_addr);
    }

    /* restore CSR6 */
    HG_GMAC_REG_OPT(gmac->hw->CSR6 = csr_temp);

    /* RI interrupt enable */
    HG_GMAC_REG_OPT(gmac->hw->CSR7 = (HG_GMAC_CSR7_AIE_EN | HG_GMAC_CSR7_NIE_EN | HG_GMAC_CSR7_RIE_EN | HG_GMAC_CSR7_RUE_EN));

    gmac->ctrl_data.miss_frame_cnt = 0;
    gmac->ctrl_data.reset_flag     = 0;

    irq_enable(gmac->irq_num);
}
#endif

static const struct netdev_hal_ops gmac_ops = {
    .open              = hg_gmac_open,
    .close             = hg_gmac_close,
    .ioctl             = hg_gmac_ioctl,
    .send_data         = hg_gmac_send_data,
    .send_scatter_data = hg_gmac_send_scatter_data,
    .mdio_read         = hg_gmac_mdio_read,
    .mdio_write        = hg_gmac_mdio_write,
	.phy_event         = hg_gmac_phy_event,
};
__init int32 hg_gmac_attach(uint32 dev_id, struct hg_gmac_eva *gmac)
{
    gmac->opened                = 0;
    gmac->dev.dev.ops           = (const struct devobj_ops *)&gmac_ops;
    gmac->input_cb              = NULL;
    gmac->speed                 = 0;
    gmac->duplex                = -1;
    gmac->link_status           = LINK_DOWN;

#if HG_GMAC_FIX_BUG_RESET_EN /* clear flag */
    gmac->ctrl_data.reset_flag  = 0;
    gmac->ctrl_data.tx_flag     = 0;
    gmac->ctrl_data.rx_flag     = 0;
#endif

    os_memset(gmac->mac_addr, 0xFF, 6);
    os_memset(&gmac->statistics, 0, sizeof(gmac->statistics));

    os_sema_init(&gmac->receive_sema, 0);
    os_mutex_init(&gmac->mdio_mutex);
    _OS_TASK_INIT("GMAC rx", &gmac->receive_task, hg_gmac_receive_frame_thread, (uint32)gmac, OS_TASK_PRIORITY_HIGH + 7, 512);

    if (gmac->mdio_pin) {
        gpio_set_dir(gmac->mdio_pin, GPIO_DIR_OUTPUT);
        gpio_set_dir(gmac->mdc_pin, GPIO_DIR_OUTPUT);
    }

    irq_disable(gmac->irq_num);
    dev_register(dev_id, (struct dev_obj *)gmac);
    return RET_OK;
}

