#include "sys_config.h"
#include "typesdef.h"
#include "list.h"
#include "errno.h"
#include "dev.h"
#include "osal/string.h"
#include "osal/irq.h"
#include "osal/semaphore.h"
#include "osal/mutex.h"
#include "osal/task.h"
#include "hal/netdev.h"
#include "hal/dma.h"
#include "hal/crc.h"
#include "lib/common/sysevt.h"
#include "lib/net/ethphy/eth_phy.h"
#include "lib/net/ethphy/eth_mdio_bus.h"
#include "hg_gmac_eva_v2_hw.h"
#include "dev/emac/hg_gmac_eva_v2.h"
#include "hal/gpio.h"

extern int32 _os_task_set_priority(struct os_task *task, uint8 priority);
#define _OS_TASK_INIT(name, task, func, data, prio, stksize) do { \
        os_task_init((const uint8 *)name, task, (os_task_func_t)func, (uint32)data); \
        os_task_set_stacksize(task, stksize); \
        _os_task_set_priority(task, prio); \
        os_task_run(task);\
    }while(0)

//To fix gmac bugs
__weak void gmac_csr_dv_disable(int dev_id)
{
}

//To fix gmac bugs
__weak void gmac_csr_dv_enable(int dev_id)
{
}

static void hg_gmac_irq_handler(void *data)
{
    struct hg_gmac_eva_v2    *dev = (struct hg_gmac_eva_v2 *)data;
    struct hg_gmac_eva_v2_hw *hw  = (struct hg_gmac_eva_v2_hw *)dev->hw;
    uint32 csr_temp;
    
    HG_GMAC_V2_REG_OPT(
        csr_temp = hw->CSR5;
    );
    if(csr_temp & (HG_GMAC_V2_CSR5_RI_PENDING | HG_GMAC_V2_CSR5_RU_PENDING)) {
        //disable IRQ
        HG_GMAC_V2_REG_OPT(
            hw->CSR7 = ~(HG_GMAC_V2_CSR7_AIE_EN | HG_GMAC_V2_CSR7_NIE_EN |
                         HG_GMAC_V2_CSR7_RIE_EN | HG_GMAC_V2_CSR7_RUE_EN);
        );
        
        HG_GMAC_V2_REG_OPT(
            hw->CSR5 = HG_GMAC_V2_CSR5_RI_PENDING;
        );
        
        os_sema_up(&dev->receive_sema);
    }
}

//Ethernet receiving thread
static void hg_gmac_v2_receive_frame_thread(void *argument)
{
    struct netdev *ndev = (struct netdev *)argument;
    struct hg_gmac_eva_v2    *dev = (struct hg_gmac_eva_v2 *)ndev;
    struct hg_gmac_eva_v2_hw *hw  = (struct hg_gmac_eva_v2_hw *)dev->hw;

    while(1) {
        os_sema_down(&dev->receive_sema, osWaitForever);

        while(hg_gmac_v2_has_received_frame(ndev) == RET_OK) {
            hg_gmac_v2_receive_data(ndev);
        }
        
        //clear pending
        HG_GMAC_V2_REG_OPT(
            hw->CSR5 = HG_GMAC_V2_CSR5_RI_PENDING | HG_GMAC_V2_CSR5_RU_PENDING;
        );

        /* BUG FIX: RU pending later than descriptor */
        /* rekick */
        HG_GMAC_V2_REG_OPT(
            hw->CSR2 = 0x0000;
        );
        
        //enable RI&RU IRQ
        HG_GMAC_V2_REG_OPT(
            hw->CSR7 = HG_GMAC_V2_CSR7_AIE_EN | HG_GMAC_V2_CSR7_NIE_EN | 
                       HG_GMAC_V2_CSR7_RIE_EN | HG_GMAC_V2_CSR7_RUE_EN;
        );
    }
}

static void hg_gmac_v2_statistics_printf(struct netdev *ndev)
{
    struct hg_gmac_eva_v2 *dev = (struct hg_gmac_eva_v2 *)ndev;
    
    gmac_v2_dbg("gmac xfer:\r\n    tx:%d, rx:%d, err:%d, rx overflow:%d\r\n",
             dev->statistics.tx_cnt,
             dev->statistics.rx_cnt,
             dev->statistics.rx_err_cnt,
             dev->statistics.ru_pending_cnt);
}

static void hg_gmac_v2_phy_link_change(void *dev)
{
    struct ethernet_phy_device *phydev  = (struct ethernet_phy_device *)dev;
    struct hg_gmac_eva_v2 *gmac         = (struct hg_gmac_eva_v2 *)phydev->ndev;
    struct hg_gmac_eva_v2_hw        *hw = (struct hg_gmac_eva_v2_hw *)gmac->hw;
    
    uint32 reg;
    uint32 csr_temp;

    if (!gmac->opened) {
        return;
    }

    if (phydev->link) {
        if ((phydev->last_speed != phydev->speed) ||
            (phydev->last_duplex != phydev->duplex)) {

            /* Speed and duplex settings are only possible when the MAC
             * is in STOP.
             */
            phydev->last_speed  = 0;
            phydev->last_duplex = -1;
            
            HG_GMAC_V2_REG_OPT(
                csr_temp  = hw->CSR6;
                csr_temp &= ~(HG_GMAC_V2_CSR6_ST_EN | HG_GMAC_V2_CSR6_SR_EN);
            );
            HG_GMAC_V2_REG_OPT(
                hw->CSR6 = csr_temp;
            );
            HG_GMAC_V2_REG_OPT(
                csr_temp = hw->CSR5;
            );
            /* Don't wait to stop */
            if(HG_GMAC_V2_CSR5_TS_GET(csr_temp) || HG_GMAC_V2_CSR5_RS_GET(csr_temp)) {
                return;
            }
            HG_GMAC_V2_REG_OPT(
                reg = hw->CSR6;
            );
            /* Clear speed and duplex settings */
            reg &= ~(HG_GMAC_V2_CSR6_FD | HG_GMAC_V2_CSR6_SPEED_MASK);
                
            if(phydev->duplex) {
                reg |= HG_GMAC_V2_CSR6_FD;
            } else {
                reg &= ~HG_GMAC_V2_CSR6_FD;
            }
            
            switch(phydev->speed) {
            case SPEED_10:
                reg |= HG_GMAC_V2_CSR6_SPEED_SET(HG_GMAC_V2_ETHERNET_10M);
                break;
            case SPEED_100:
                reg |= HG_GMAC_V2_CSR6_SPEED_SET(HG_GMAC_V2_ETHERNET_100M);
                break;
            case SPEED_1000:
                reg |= HG_GMAC_V2_CSR6_SPEED_SET(HG_GMAC_V2_ETHERNET_1G);
                break;
            }
            HG_GMAC_V2_REG_OPT(
                hw->CSR6 = reg;
            );
            /* Start the sending and receiving functions of the MAC */
            HG_GMAC_V2_REG_OPT(
                csr_temp  = hw->CSR6;
                csr_temp |= HG_GMAC_V2_CSR6_ST_EN | HG_GMAC_V2_CSR6_SR_EN;
            );
            HG_GMAC_V2_REG_OPT(
                hw->CSR6 = csr_temp;
            );
            /* clear pending */
            HG_GMAC_V2_REG_OPT(
                hw->CSR5 = HG_GMAC_V2_CSR5_TPS_PENDING | HG_GMAC_V2_CSR5_RPS_PENDING |
                           HG_GMAC_V2_CSR5_RU_PENDING;
            );
            
            phydev->last_speed  = phydev->speed;
            phydev->last_duplex = phydev->duplex;
            
            gmac->link_status   = LINK_OK;
            gmac->speed         = phydev->speed;
            gmac->duplex        = phydev->duplex;
            
            SYSEVT_NEW_NETWORK_EVT(SYSEVT_GMAC_LINK_UP, phydev->speed);
            gmac_v2_dbg("***ethernet link up:%d %d\r\n", phydev->duplex, phydev->speed);
        }
    }

    if (phydev->link != phydev->last_link) {
        if (!phydev->link) {
            SYSEVT_NEW_NETWORK_EVT(SYSEVT_GMAC_LINK_DOWN, 0);
            gmac_v2_dbg("***ethernet link lost\r\n");
            
            gmac->link_status   = LINK_DOWN;
            gmac->speed         = 0;
            gmac->duplex        = -1;
            
            phydev->last_speed  = 0;
            phydev->last_duplex = -1;
            
            hg_gmac_v2_statistics_printf(phydev->ndev);
            
            /* The MAC goes to the STOP state */
            HG_GMAC_V2_REG_OPT(
                csr_temp  = hw->CSR6;
                csr_temp &= ~(HG_GMAC_V2_CSR6_ST_EN | HG_GMAC_V2_CSR6_SR_EN);
            );
            HG_GMAC_V2_REG_OPT(
                hw->CSR6 = csr_temp;
            );
            /* Don't wait to stop */
            HG_GMAC_V2_REG_OPT(
                csr_temp = hw->CSR5;
            );
            if(HG_GMAC_V2_CSR5_TS_GET(csr_temp) || HG_GMAC_V2_CSR5_RS_GET(csr_temp)) {
                return;
            }
        }
        phydev->last_link = phydev->link;
    }
}

static int32 hg_gmac_v2_get_link_speed(struct netdev *ndev)
{
    struct hg_gmac_eva_v2 *dev = (struct hg_gmac_eva_v2 *)ndev;
    
    return dev->speed;
}

static int32 hg_gmac_v2_get_link_status(struct netdev *ndev)
{
    struct hg_gmac_eva_v2 *dev = (struct hg_gmac_eva_v2 *)ndev;
    
    return dev->link_status;
}

/**
  * @brief  The MII management interface sends data
  * @param  emac_dev: GMAC module pointer
  * @param  phy_addr: phy address
  * @param  reg_addr: register address
  * @param  data    : Data to send
  * @retval None
  * @note   Data format symbol IEEE802.3 clause 22
  */
static void hg_gmac_v2_mdio_write(struct netdev *ndev, uint16 phy_addr, uint16 reg_addr, uint16 data)
{
    struct hg_gmac_eva_v2 *dev = (struct hg_gmac_eva_v2 *)ndev;
    
    os_mutex_lock(&dev->mdio_mutex, osWaitForever);

    uint32 i;
    //preamble
    HG_GMAC_V2_MDC_LOW(dev);
    HG_GMAC_V2_MDIO_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    for(i=0; i<32; i++) {
        HG_GMAC_V2_MDC_HIGH(dev);
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_LOW(dev);
        HG_GMAC_V2_DELAY(dev);
    }
    //ST
    HG_GMAC_V2_MDIO_LOW(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    HG_GMAC_V2_MDC_LOW(dev);
    
    HG_GMAC_V2_MDIO_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    HG_GMAC_V2_MDC_LOW(dev);
    //OP
    HG_GMAC_V2_MDIO_LOW(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    HG_GMAC_V2_MDC_LOW(dev);
    
    HG_GMAC_V2_MDIO_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    HG_GMAC_V2_MDC_LOW(dev);
    //PHYAD
    for(i=0; i<5; i++) {
        if(phy_addr & BIT(4-i)) {
            HG_GMAC_V2_MDIO_HIGH(dev);
        } else {
            HG_GMAC_V2_MDIO_LOW(dev);
        }
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_HIGH(dev);
        
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_LOW(dev);
    }
    //REGAD
    for(i=0; i<5; i++) {
        if(reg_addr & BIT(4-i)) {
            HG_GMAC_V2_MDIO_HIGH(dev);
        } else {
            HG_GMAC_V2_MDIO_LOW(dev);
        }
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_HIGH(dev);
        
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_LOW(dev);
    }
    //TA
    HG_GMAC_V2_MDIO_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    HG_GMAC_V2_MDC_LOW(dev);
    
    HG_GMAC_V2_MDIO_LOW(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    HG_GMAC_V2_MDC_LOW(dev);
    //DATA
    for(i=0; i<16; i++) {
        if(data & BIT(15-i)) {
            HG_GMAC_V2_MDIO_HIGH(dev);
        } else {
            HG_GMAC_V2_MDIO_LOW(dev);
        }
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_HIGH(dev);
        
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_LOW(dev);
    }
    
    /* Looks like I have to go through a few more IOs to ensure that the
     * data has been written in? 
     */
    HG_GMAC_V2_MDC_LOW(dev);
    HG_GMAC_V2_MDIO_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    for(i=0; i<32; i++) {
        HG_GMAC_V2_MDC_HIGH(dev);
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_LOW(dev);
        HG_GMAC_V2_DELAY(dev);
    }

    os_mutex_unlock(&dev->mdio_mutex);
}

/**
  * @brief  The MII management interface receives data
  * @param  emac_dev: GMAC module pointer
  * @param  phy_addr: phy address
  * @param  reg_addr: register address
  * @retval Return the read data
  * @note   Data format symbol IEEE802.3 clause 22
  */
static int32 hg_gmac_v2_mdio_read(struct netdev *ndev, uint16 phy_addr, uint16 reg_addr)
{
    struct hg_gmac_eva_v2 *dev = (struct hg_gmac_eva_v2 *)ndev;
    uint16 data;
    
    os_mutex_lock(&dev->mdio_mutex, osWaitForever);

    uint32 i;
//    int ta;
    
    data = 0;
    //preamble
    HG_GMAC_V2_MDC_LOW(dev);
    HG_GMAC_V2_MDIO_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    for(i=0; i<32; i++) {
        HG_GMAC_V2_MDC_HIGH(dev);
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_LOW(dev);
        HG_GMAC_V2_DELAY(dev);
    }
    //ST
    HG_GMAC_V2_MDIO_LOW(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    HG_GMAC_V2_MDC_LOW(dev);
    
    HG_GMAC_V2_MDIO_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    HG_GMAC_V2_MDC_LOW(dev);
    //OP
    HG_GMAC_V2_MDIO_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    HG_GMAC_V2_MDC_LOW(dev);
    
    HG_GMAC_V2_MDIO_LOW(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    HG_GMAC_V2_MDC_LOW(dev);
    //PHYAD
    for(i=0; i<5; i++) {
        if(phy_addr & BIT(4-i)) {
            HG_GMAC_V2_MDIO_HIGH(dev);
        } else {
            HG_GMAC_V2_MDIO_LOW(dev);
        }
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_HIGH(dev);
        
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_LOW(dev);
    }
    //REGAD
    for(i=0; i<5; i++) {
        if(reg_addr & BIT(4-i)) {
            HG_GMAC_V2_MDIO_HIGH(dev);
        } else {
            HG_GMAC_V2_MDIO_LOW(dev);
        }
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_HIGH(dev);
        
        HG_GMAC_V2_DELAY(dev);
        HG_GMAC_V2_MDC_LOW(dev);
    }
    //TA
    HG_GMAC_V2_MDIO_SET_INPUT(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDC_LOW(dev);
    HG_GMAC_V2_DELAY(dev);
    
    /*ta = HG_GMAC_V2_MDIO_GET(dev);*/
    HG_GMAC_V2_MDC_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);
    //DATA
    for(i=0; i<16; i++) {
        HG_GMAC_V2_MDC_LOW(dev);
        if(HG_GMAC_V2_MDIO_GET(dev)) {
            data |= BIT(15-i);
        }
        HG_GMAC_V2_DELAY(dev);
        
        HG_GMAC_V2_MDC_HIGH(dev);
        HG_GMAC_V2_DELAY(dev);
    }
    //IDLE
    HG_GMAC_V2_MDC_LOW(dev);
    HG_GMAC_V2_DELAY(dev);
    
    HG_GMAC_V2_MDIO_SET_OUTPUT(dev);
    HG_GMAC_V2_MDIO_HIGH(dev);
    HG_GMAC_V2_DELAY(dev);

    os_mutex_unlock(&dev->mdio_mutex);
    
    return data;
}

static void hg_gmac_v2_init(struct hg_gmac_eva_v2_hw *p_gmac)
{
    /* reset & clock selection */
    SYSCTRL_REG_OPT(
        //enable clk
        SYSCTRL->CLK_CON3  |= BIT(17);
        os_sleep_us(10);
        //remove reset
        SYSCTRL->SYS_CON1  |= BIT(16);
        os_sleep_us(10);
        //enable dma
        SYSCTRL->SYS_CON2  |= BIT(7);
    );  //gmac clock from io

    //disable MDC AUTO CLK
    HG_GMAC_V2_REG_OPT(p_gmac->CSR10 = BIT(31););
    while(p_gmac->CSR10 & BIT(31)) {
        __asm("nop");
    }
    
    //use software controllable
    //MDIO set to output. MDC&MDIO set low.
    HG_GMAC_V2_REG_OPT(p_gmac->CSR9 = BIT(18););
    
    /* PBL cannot be 0, the recommended setting is 16 */
    /* disable transmit automatic polling */
    HG_GMAC_V2_REG_OPT(
        p_gmac->CSR0 = HG_GMAC_V2_CSR0_TAP_SET(0) |
                       HG_GMAC_V2_CSR0_PBL_SET(HG_GMAC_V2_PBL_16);
    );

    /* clear all pending */
    HG_GMAC_V2_REG_OPT(p_gmac->CSR5  = 0x00004DE7;);
    /* disable all interrupt */
    HG_GMAC_V2_REG_OPT(p_gmac->CSR7  = 0x00000000;);
}

static void hg_gmac_v2_descriptor_init(struct hg_gmac_data_v2 *p_ctrl)
{
    uint32 i;
    struct hg_gmac_v2_rx_descriptor *p_rx_des_buf = p_ctrl->p_rx_des_buf;
    struct hg_gmac_v2_tx_descriptor *p_tx_des_buf = p_ctrl->p_tx_des_buf;
    
    /* initialization descriptor */
    os_memset(p_ctrl->p_rx_des_buf, 0, sizeof(struct hg_gmac_v2_rx_descriptor) * p_ctrl->rx_des_num);
    os_memset(p_ctrl->p_tx_des_buf, 0, sizeof(struct hg_gmac_v2_tx_descriptor) * p_ctrl->tx_des_num);
    /* rx descriptor */
    for(i=0; i<p_ctrl->rx_des_num; i++) {
        p_rx_des_buf[i].own                 = 1;
        /* use ring mode */
        p_rx_des_buf[i].second_addr_chained = 0;
        p_rx_des_buf[i].buf_1_size          = HG_GMAC_V2_RX_PER_BUF_SIZE;
        p_rx_des_buf[i].rx_buf_addr_1       = (uint32)&p_ctrl->p_rx_buf[i * HG_GMAC_V2_RX_PER_BUF_SIZE];
        /* Point to the next descriptor */
        p_rx_des_buf[i].p_next              = &p_rx_des_buf[i+1];
    }
    /* the last rx descriptor */
    p_rx_des_buf[p_ctrl->rx_des_num-1].buf_1_size     = HG_GMAC_V2_RX_FRAME_MAX_SIZE;
    p_rx_des_buf[p_ctrl->rx_des_num-1].p_next         = &p_rx_des_buf[0];
    /* The ring mode requires the end_of_ring to be set in the last descriptor */
    p_rx_des_buf[p_ctrl->rx_des_num-1].end_of_ring    = 1;

    /* tx descriptor */
    for(i=0; i<p_ctrl->tx_des_num; i++) {
        p_tx_des_buf[i].own                 = 0;
        /*! The hardware module is limited, and one frame can only correspond to one
         *  descriptor.
         */
        p_tx_des_buf[i].first_descriptor    = 1;
        p_tx_des_buf[i].last_descriptor     = 1;
        /* use ring mode */
        p_tx_des_buf[i].second_addr_chained = 0;
        p_tx_des_buf[i].tx_buf_addr_1       = (uint32)&p_ctrl->p_tx_buf[i * HG_GMAC_V2_TX_PER_BUF_SIZE];
        /* Point to the next descriptor */
        p_tx_des_buf[i].p_next              = &p_tx_des_buf[i+1];
    }
    p_tx_des_buf[p_ctrl->tx_des_num-1].p_next      = &p_tx_des_buf[0];
    /* The ring mode requires the end_of_ring to be set in the last descriptor */
    p_tx_des_buf[p_ctrl->tx_des_num-1].end_of_ring = 1;
}

static int32 hg_gmac_v2_send_data(struct netdev *ndev, uint8 *p_data, uint32 size)
{
    struct hg_gmac_eva_v2    *dev = (struct hg_gmac_eva_v2 *)ndev;
    struct hg_gmac_eva_v2_hw *hw  = (struct hg_gmac_eva_v2_hw *)dev->hw;
    struct hg_gmac_v2_tx_descriptor volatile  *p_tx_des;
    uint32 csr_temp;

    if (!dev->opened) {
        return RET_ERR;
    }
    
    if(size > 1514) {
        return RET_ERR;
    }
    
    //no link?
    if(dev->link_status != LINK_OK) {
        return RET_ERR;
    }
    
    //no need to send
    if(size == 0) {
        return RET_OK;
    }

    os_mutex_lock(&dev->send_mutex, osWaitForever);

    p_tx_des = dev->ctrl_data.p_tx_des;
    //Wait for the free descriptor to be released
    while(p_tx_des->own) {
        //tx stop?
        HG_GMAC_V2_REG_OPT(
            csr_temp  = hw->CSR6;
        );
        if(!(csr_temp & HG_GMAC_V2_CSR6_ST_EN)) {
            os_mutex_unlock(&dev->send_mutex);
            return RET_ERR;
        }
    }
    
    /* Recovery descriptor */
    if(p_tx_des->setup_packet) {
        p_tx_des->setup_packet         = 0;
        p_tx_des->filtering_type_1     = 0;
        p_tx_des->filtering_type_0     = 0;
        p_tx_des->first_descriptor     = 1;
        p_tx_des->last_descriptor      = 1;
    }
    
    hw_memcpy((void *)p_tx_des->tx_buf_addr_1, p_data, size);

    p_tx_des->buf_1_size        = size;
    p_tx_des->int_on_completion = 1;
    p_tx_des->own               = 1;
    /* The descriptor automatically points to the next descriptor */
    dev->ctrl_data.p_tx_des = p_tx_des->p_next;
    
    /* kick tx start */
//    HG_GMAC_V2_REG_OPT (
//        dev->hw->CSR5 = HG_GMAC_V2_CSR5_TU_PENDING | HG_GMAC_V2_CSR5_UNF_PENDING;
//    );
    HG_GMAC_V2_REG_OPT(hw->CSR1 = 0x00;);
    
    dev->statistics.tx_cnt++;
    dev->dev.tx_bytes += size;

    os_mutex_unlock(&dev->send_mutex);
    
    return RET_OK;
}

//Send segmented Ethernet frames
static int32 hg_gmac_v2_send_scatter_data(struct netdev *ndev, scatter_data *p_data, uint32 count)
{
    uint32 len = 0;
    uint32 addr;
    struct hg_gmac_eva_v2 *dev = (struct hg_gmac_eva_v2 *)ndev;
    struct hg_gmac_eva_v2_hw *hw  = (struct hg_gmac_eva_v2_hw *)dev->hw;
    struct hg_gmac_v2_tx_descriptor volatile  *p_tx_des;
    uint32 csr_temp;

    if (!dev->opened) {
        return RET_ERR;
    }

    //no link?
    if(dev->link_status != LINK_OK) {
        return RET_ERR;
    }
    
    //no need to send
    if(count == 0) {
        return RET_OK;
    }

    os_mutex_lock(&dev->send_mutex, osWaitForever);

    p_tx_des = dev->ctrl_data.p_tx_des;
    addr = p_tx_des->tx_buf_addr_1;
    //Wait for the free descriptor to be released
    while(p_tx_des->own) {
        //tx stop?
        HG_GMAC_V2_REG_OPT(
            csr_temp  = hw->CSR6;
        );
        if(!(csr_temp & HG_GMAC_V2_CSR6_ST_EN)) {
            os_mutex_unlock(&dev->send_mutex);
            return RET_ERR;
        }
    }

    /* Recovery descriptor */
    if(p_tx_des->setup_packet) {
        p_tx_des->setup_packet         = 0;
        p_tx_des->filtering_type_1     = 0;
        p_tx_des->filtering_type_0     = 0;
        p_tx_des->first_descriptor     = 1;
        p_tx_des->last_descriptor      = 1;
    }
    
    while(count--) {
        len += p_data->size;
        if(len > 1514) {
            os_mutex_unlock(&dev->send_mutex);
            return RET_ERR;
        }
        hw_memcpy((void *)addr, (void *)p_data->addr, p_data->size);
        addr += p_data->size;
        p_data++;
    }

    //no need to send
    if(len == 0) {
        os_mutex_unlock(&dev->send_mutex);
        return RET_OK;
    }
    
    p_tx_des->buf_1_size        = len;
    p_tx_des->int_on_completion = 1;
    p_tx_des->own               = 1;
    /* The descriptor automatically points to the next descriptor */
    dev->ctrl_data.p_tx_des = p_tx_des->p_next;
    
    /* kick tx start */
//    HG_GMAC_V2_REG_OPT (
//        hw->CSR5 = HG_GMAC_V2_CSR5_TU_PENDING | HG_GMAC_V2_CSR5_UNF_PENDING;
//    );
    HG_GMAC_V2_REG_OPT(hw->CSR1 = 0x00;);

    dev->statistics.tx_cnt++;
    dev->dev.tx_bytes += len;

    os_mutex_unlock(&dev->send_mutex);

    return RET_OK;
}

int32 hg_gmac_v2_has_received_frame(struct netdev *ndev)
{
    struct hg_gmac_eva_v2 *dev = (struct hg_gmac_eva_v2 *)ndev;
    
    struct hg_gmac_v2_rx_descriptor *p_rx = (void *)dev->ctrl_data.p_rx_des;
    
    while(1) {
        if(p_rx->own) {
            return RET_ERR;
        } else if(p_rx->last_descriptor) {
            return RET_OK;
        }
        p_rx = p_rx->p_next;
    }
}

int32 hg_gmac_v2_receive_data(struct netdev *ndev)
{
    struct hg_gmac_eva_v2    *dev = (struct hg_gmac_eva_v2 *)ndev;
    struct hg_gmac_eva_v2_hw *hw  = (struct hg_gmac_eva_v2_hw *)dev->hw;
    uint32 csr_temp;
    netdev_input_cb input_cb;
    void *input_priv;

    struct hg_gmac_v2_rx_descriptor *p_rx, *p_rx_start;
    p_rx = p_rx_start = (void *)dev->ctrl_data.p_rx_des;
    
    dev->statistics.rx_cnt++;
    
    /* Find the last descriptor */
    while(1) {
        if(p_rx->last_descriptor) {
            break;
        }
        p_rx = p_rx->p_next;
        /* As long as the start of the start descriptor is not released,
         * there will be no problem.
         */
        p_rx->own = 1;
    }
    
    csr_temp = disable_irq();
    input_cb = dev->input_cb;
    input_priv = dev->input_priv;
    enable_irq(csr_temp);

    /* The frame can be copied without error and no truncation */
    if(!p_rx->err_summary && input_cb) {
        input_cb(ndev, (void *)p_rx_start->rx_buf_addr_1, p_rx->frame_len-4, input_priv);
        dev->dev.rx_bytes += p_rx->frame_len-4;
    } else {
        dev->statistics.rx_err_cnt++;
    }

    /* Release descriptor */
    p_rx_start->own = 1;
    /* The descriptor automatically points to the next descriptor */
    dev->ctrl_data.p_rx_des = p_rx->p_next;
    
    /* rx suspend -> rx running */
    HG_GMAC_V2_REG_OPT(
        csr_temp = hw->CSR5;
    );
    if(csr_temp & HG_GMAC_V2_CSR5_RU_PENDING) {
        
        gmac_v2_dbg("gmac_ru\r\n");
        
        dev->statistics.ru_pending_cnt++;
        
        HG_GMAC_V2_REG_OPT(
            hw->CSR5 = HG_GMAC_V2_CSR5_RU_PENDING;
        );
        HG_GMAC_V2_REG_OPT(
            hw->CSR2 = 0x0000;
        );
    }
    return RET_OK;
}

static int32 hg_gmac_v2_set_filter_mac(struct netdev *ndev, const void *mac_table, uint32 size)
{
    /***** setup frame send *****/
    struct hg_gmac_v2_setup_perfect_filter *p_filter;
    uint32 i, csr_temp, mac_cnt;
    const uint8 *p_addr = (const uint8 *)mac_table;
    struct hg_gmac_eva_v2    *dev = (struct hg_gmac_eva_v2 *)ndev;
    struct hg_gmac_eva_v2_hw *hw  = (struct hg_gmac_eva_v2_hw *)dev->hw;
    struct hg_gmac_v2_tx_descriptor volatile  *p_tx_des = dev->ctrl_data.p_tx_des;
    p_filter = (struct hg_gmac_v2_setup_perfect_filter *)p_tx_des->tx_buf_addr_1;

    if (!dev->opened) {
        gmac_v2_dbg("set filter mac fail1\r\n");
        return RET_ERR;
    }

    /* ADDR is NULL */
    if (!p_addr) {
        gmac_v2_dbg("set filter mac fail2\r\n");
        return RET_ERR;
    }

    os_mutex_lock(&dev->send_mutex, osWaitForever);

    /* mac table length more than 192byte or mac table length less than (6)byte */
    mac_cnt = size / (6);
    if ((size > 192) || (!mac_cnt)) {
        gmac_v2_dbg("set filter mac fail3\r\n");
        os_mutex_unlock(&dev->send_mutex);
        return RET_ERR;
    }
    
    //Wait for the free descriptor to be released
    while(p_tx_des->own) {
        //tx stop?
        HG_GMAC_V2_REG_OPT(
            csr_temp  = hw->CSR6;
        );
        if(!(csr_temp & HG_GMAC_V2_CSR6_ST_EN)) {
           gmac_v2_dbg("set filter mac fail4\r\n");
           os_mutex_unlock(&dev->send_mutex);
            return RET_ERR;
        }
    }

    for(i=0; i<sizeof(p_filter->mac_addr)/sizeof(p_filter->mac_addr[0]); i++) {
        if (mac_cnt > 0) {
            p_filter->mac_addr[i].addr_15_00 = (*(p_addr+1) << 8) | (*(p_addr+0));
            p_filter->mac_addr[i].addr_31_16 = (*(p_addr+3) << 8) | (*(p_addr+2));
            p_filter->mac_addr[i].addr_47_32 = (*(p_addr+5) << 8) | (*(p_addr+4));
            mac_cnt--;
            p_addr+=6;
        } else {
            /* fit the first mac addr if ma_cnt less than 16 */
            p_filter->mac_addr[i].addr_15_00 = (*(((const uint8 *)mac_table)+1) << 8) | (*(((const uint8 *)mac_table)+0));
            p_filter->mac_addr[i].addr_31_16 = (*(((const uint8 *)mac_table)+3) << 8) | (*(((const uint8 *)mac_table)+2));
            p_filter->mac_addr[i].addr_47_32 = (*(((const uint8 *)mac_table)+5) << 8) | (*(((const uint8 *)mac_table)+4));
        }
    }

//    for (i=0; i<sizeof(p_filter->mac_addr)/sizeof(p_filter->mac_addr[0]); i++) {
//        gmac_v2_dbg("mac:%x-%x-%x\r\n", p_filter->mac_addr[i].addr_15_00, p_filter->mac_addr[i].addr_31_16, p_filter->mac_addr[i].addr_47_32);
//    }
    

    /* interrupt on completion */
    p_tx_des->int_on_completion = 1;
    /* clear first&last descriptor */
    p_tx_des->first_descriptor  = 0;
    p_tx_des->last_descriptor   = 0;
    
    /* configurate destination address filter mode(PERFECT_FILTER) */
    p_tx_des->filtering_type_1  = 0;
    p_tx_des->filtering_type_0  = 0;
    
    /* setup packet */
    p_tx_des->setup_packet      = 1;
    /* size = 192byte */
    p_tx_des->buf_1_size        = 192;
    p_tx_des->own               = 1;
    
    dev->ctrl_data.p_tx_des = p_tx_des->p_next;

    //Need to kick tx for gmac module receives the setup frame
    HG_GMAC_V2_REG_OPT(hw->CSR1 = 0x00;);

    gmac_v2_dbg("set filter mac ok\r\n");

    os_mutex_unlock(&dev->send_mutex);
    
    return RET_OK;
}

static int32 hg_gmac_v2_set_mac_addr(struct netdev *ndev, const void *addr)
{
    struct hg_gmac_eva_v2  *dev = (struct hg_gmac_eva_v2 *)ndev;

    if (!dev) {
        return RET_ERR;
    }

    /* save mac addr */
    memcpy(dev->mac_addr, addr, 6);


    return RET_OK;
}


static void hg_gmac_v2_phy_event(void *phy, uint32 event, uint32 param1, uint32 param2)
{
    switch (event) {
        case NETDEV_PHY_EVENT_LINK_CHANGED:
            hg_gmac_v2_phy_link_change(phy);
            break;
        default:
            break;
    }
}

static int32 hg_gmac_v2_ioctl(struct netdev *ndev, uint32 cmd, uint32 param1, uint32 param2){

    int32 ret_val = -ENOTSUPP;
    struct hg_gmac_eva_v2    *dev = (struct hg_gmac_eva_v2 *)ndev;

    if (!dev->opened) {
        return RET_ERR;
    }

    switch (cmd) {
        case NETDEV_IOCTL_GET_ADDR:
            os_memcpy((uint8 *)param1, dev->mac_addr, 6);
            ret_val = RET_OK;
            break;
        case NETDEV_IOCTL_SET_ADDR:
            ret_val = hg_gmac_v2_set_mac_addr(ndev, (uint8 *)param1);
            break;
        case NETDEV_IOCTL_GET_LINK_STATUS:
            ret_val = hg_gmac_v2_get_link_status(ndev);
            break;
        case NETDEV_IOCTL_GET_LINK_SPEED:
            ret_val = hg_gmac_v2_get_link_speed(ndev);
            break;
        case NETDEV_IOCTL_SET_FILTER_MAC:
            ret_val = hg_gmac_v2_set_filter_mac(ndev, (const void*)param1, param2);
            break;
//        case NETDEV_IOCTL_FORCE_LINK:
//            ret_val = hg_gmac_v2_force_link(ndev, param1, param2);
//            break;
        default:
            break;
    }

    return ret_val;

}






__init static int32 hg_gmac_v2_open(struct netdev *ndev, netdev_input_cb input_cb, netdev_event_cb evt_cb, void *priv)
{
    struct hg_gmac_v2_setup_perfect_filter *p_filter = NULL;
    struct ethernet_phy_device             *phydev   = NULL;
    struct ethernet_mdio_bus               *mdio_bus = NULL;
    struct hg_gmac_eva_v2                  *dev      = (struct hg_gmac_eva_v2 *)ndev;
    struct hg_gmac_eva_v2_hw               *hw       = (struct hg_gmac_eva_v2_hw *)dev->hw;
    struct hg_gmac_v2_tx_descriptor volatile  *p_tx_des = NULL;
    const uint8 default_mac_addr[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,};
    int32 ret = 0;

    if (dev->opened) {
        goto _DONE;
    }

    /* 清0信号量 */
    while (1) {
        if (!os_sema_down(&dev->receive_sema, 0)) {
            break;
        }
    }

//    /* 清0互斥量 */
//    while (1) {
//        if (!os_mutex_unlock(&dev->mdio_mutex)) {
//            break;
//        }
//    }


    /* +7 for 8byte alignment */
    if(dev->tx_buf_size < HG_GMAC_V2_TX_MIN_BUF_SIZE + 7) {
        ASSERT(dev->tx_buf_size >= HG_GMAC_V2_TX_MIN_BUF_SIZE + 7);
        return RET_ERR;
    }
    
    /* +7 for 8byte alignment. The number of rx descriptors must be greater than 2. */
    if(dev->rx_buf_size < HG_GMAC_V2_RX_MIN_BUF_SIZE + 7) {
        ASSERT(dev->rx_buf_size >= HG_GMAC_V2_RX_MIN_BUF_SIZE + 7);
    }
    
    dev->ctrl_data.tx_des_num  = (dev->tx_buf_size - 7)/(sizeof(struct hg_gmac_v2_descriptor) + HG_GMAC_V2_TX_PER_BUF_SIZE);
    dev->ctrl_data.rx_des_num  = (dev->rx_buf_size - 7 - (HG_GMAC_V2_RX_FRAME_MAX_SIZE - HG_GMAC_V2_RX_PER_BUF_SIZE)) /
                                 (sizeof(struct hg_gmac_v2_descriptor) + HG_GMAC_V2_RX_PER_BUF_SIZE);

    /* Apply for tx buffer. */
    dev->ctrl_data.p_tx_malloc = (uint8 *)os_malloc(dev->ctrl_data.tx_des_num * (sizeof(struct hg_gmac_v2_descriptor) + HG_GMAC_V2_TX_PER_BUF_SIZE) + 7);
    if(dev->ctrl_data.p_tx_malloc == NULL) {
        return RET_ERR;
    } else {
        dev->ctrl_data.p_tx_des_buf = (struct hg_gmac_v2_tx_descriptor *)(((uint32)dev->ctrl_data.p_tx_malloc + 7) & ~0x07);
        dev->ctrl_data.p_tx_buf     = (uint8 *)(dev->ctrl_data.p_tx_des_buf + dev->ctrl_data.tx_des_num);
    }
    /* Apply for rx buffer. */
    dev->ctrl_data.p_rx_malloc = (uint8 *)os_malloc(dev->ctrl_data.rx_des_num * (sizeof(struct hg_gmac_v2_descriptor) + HG_GMAC_V2_RX_PER_BUF_SIZE) +
                                                    (HG_GMAC_V2_RX_FRAME_MAX_SIZE - HG_GMAC_V2_RX_PER_BUF_SIZE) + 7);
    if(dev->ctrl_data.p_rx_malloc == NULL) {
        os_free(dev->ctrl_data.p_tx_malloc);
        return RET_ERR;
    } else {
        dev->ctrl_data.p_rx_des_buf = (struct hg_gmac_v2_rx_descriptor *)(((uint32)dev->ctrl_data.p_rx_malloc + 7) & ~0x07);
        dev->ctrl_data.p_rx_buf     = (uint8 *)(dev->ctrl_data.p_rx_des_buf + dev->ctrl_data.rx_des_num);
    }
    
    ret = pin_func(ndev->dev.dev_id, 1);
    if (ret) {
        os_free(dev->ctrl_data.p_tx_malloc);
        os_free(dev->ctrl_data.p_rx_malloc);
        return ret;
    }


    /* enable the gamc module clk to config the regeister */
    hg_gmac_v2_init((struct hg_gmac_eva_v2_hw *)hw);

    //Descriptor initialization
    hg_gmac_v2_descriptor_init(&dev->ctrl_data);
    
    //config
    HG_GMAC_V2_REG_OPT(hw->CSR3 = (uint32)dev->ctrl_data.p_rx_des_buf);
    HG_GMAC_V2_REG_OPT(hw->CSR4 = (uint32)dev->ctrl_data.p_tx_des_buf);

    /* Save the starting descriptor pointer */
    dev->ctrl_data.p_rx_des = dev->ctrl_data.p_rx_des_buf;
    dev->ctrl_data.p_tx_des = dev->ctrl_data.p_tx_des_buf;
    p_tx_des = dev->ctrl_data.p_tx_des;
    
    HG_GMAC_V2_REG_OPT(
        hw->CSR6 = HG_GMAC_V2_CSR6_PM_EN;    //Pass all multicast
    );
    
    /* Address filtering uses blacklist mode */
/***** setup frame send *****/
    
    p_filter = (struct hg_gmac_v2_setup_perfect_filter *)p_tx_des->tx_buf_addr_1;
    
    os_memset(p_filter->mac_addr, 0xFF, sizeof(p_filter->mac_addr));

    /* interrupt on completion */
    p_tx_des->int_on_completion = 1;
    /* clear first&last descriptor */
    p_tx_des->first_descriptor  = 0;
    p_tx_des->last_descriptor   = 0;
    
    /* configurate destination address filter mode(INVERSE_FILTER) */
    p_tx_des->filtering_type_1  = 1;
    p_tx_des->filtering_type_0  = 0;
    
    /* setup packet */
    p_tx_des->setup_packet      = 1;
    /* size = 192byte */
    p_tx_des->buf_1_size        = 192;
    p_tx_des->own               = 1;
    
    dev->ctrl_data.p_tx_des = p_tx_des->p_next;
/***** setup frame send end *****/

    //open auto polling
    HG_GMAC_V2_REG_OPT(
        hw->CSR0 |= HG_GMAC_V2_CSR0_TAP_SET(0x1);
    );
    
    /* RI interrupt enable */
    HG_GMAC_V2_REG_OPT(
        hw->CSR7 = HG_GMAC_V2_CSR7_AIE_EN | HG_GMAC_V2_CSR7_NIE_EN |
                   HG_GMAC_V2_CSR7_RIE_EN | HG_GMAC_V2_CSR7_RUE_EN;
    );

    if (dev->modbus_devid) {
        mdio_bus = (struct ethernet_mdio_bus *)dev_get(dev->modbus_devid);
        ASSERT(mdio_bus);
        ret = eth_mdio_bus_open(mdio_bus, ndev);
        ASSERT(!ret);
    }

    if (dev->phy_devid) {
        phydev = (struct ethernet_phy_device *)dev_get(dev->phy_devid);
        ASSERT(phydev);
        ret = eth_phy_open(phydev, mdio_bus, ndev);
        ASSERT(!ret);
    }

    if (dev->crc_devid) {
        dev->crcdev = (struct crc_dev *)dev_get(dev->crc_devid);
    }


    ret = request_irq(dev->irq_num, hg_gmac_irq_handler, dev);
    if(ret != RET_OK) {
        os_free(dev->ctrl_data.p_tx_malloc);
        os_free(dev->ctrl_data.p_rx_malloc);
        return ret;
    }

    /* create the gmac rx thread after config sucessed */
    _OS_TASK_INIT("GMAC rx", &dev->receive_task, hg_gmac_v2_receive_frame_thread, (uint32)dev, OS_TASK_PRIORITY_HIGH + 7, 512);

    irq_enable(dev->irq_num);
    dev->opened = 1;

    /* If the MAC address is not the default value, we need to configure
     * the mac address.
     */
    if(os_memcmp(dev->mac_addr, default_mac_addr, 6)) {
        hg_gmac_v2_set_mac_addr(ndev, dev->mac_addr);
    }

_DONE:
    if(input_cb){
        ret = disable_irq();
        dev->input_cb   = input_cb;
        dev->input_priv = priv;
        enable_irq(ret);
    }
    return RET_OK;
}

__init static int32 hg_gmac_v2_close(struct netdev *ndev)
{
    struct hg_gmac_eva_v2      *gmac      = (struct hg_gmac_eva_v2 *)ndev;
    struct hg_gmac_eva_v2_hw   *hw        = (struct hg_gmac_eva_v2_hw *)gmac->hw;
    struct ethernet_mdio_bus   *mdio_bus  = NULL;
    struct ethernet_phy_device *phydev    = NULL;
    int32 ret;

    if (!gmac->opened) {
        return RET_OK;
    }

    /* close the eth_phy os_work firstly , ensuring the mdio bus is idle */
    if (gmac->phy_devid) {
        phydev = (struct ethernet_phy_device *)dev_get(gmac->phy_devid);
        ASSERT(phydev);
        eth_phy_close(phydev);
    }

    /* close the mdio bus after closing eth_phy os_work */
    if (gmac->modbus_devid) {
        mdio_bus = (struct ethernet_mdio_bus *)dev_get(gmac->modbus_devid);
        ASSERT(mdio_bus);
        ret = eth_mdio_bus_close(mdio_bus);
        ASSERT(!ret);
    }
    
    irq_disable(gmac->irq_num);
    
    HG_GMAC_V2_REG_OPT(hw->CSR6 = 0x00000000);
    
    while(HG_GMAC_V2_CSR5_TS_GET(hw->CSR5)) {
        __NOP();
    }
    __NOP();
    while(HG_GMAC_V2_CSR5_RS_GET(hw->CSR6)) {
        __NOP();
    }
    __NOP();
    
    SYSCTRL_REG_OPT(
        SYSCTRL->SYS_CON1 &= ~BIT(16);
    );
    os_sleep_us(1);
    SYSCTRL_REG_OPT(
        SYSCTRL->SYS_CON1 |= BIT(16);
    );
    os_sleep_us(1);

    /* del the gamc rx thread after gmac closed */
    os_task_del(&gmac->receive_task);

    /* free malloc */
    os_free(gmac->ctrl_data.p_rx_malloc);
    os_free(gmac->ctrl_data.p_tx_malloc);
    
    gmac->opened = 0;
    
    pin_func(ndev->dev.dev_id, 0);
    
    SYSCTRL_REG_OPT(
        sysctrl_gmac_clk_close();
    );
    
    return RET_OK;
}

static const struct netdev_hal_ops gmacv2_ops = {
    .open              = hg_gmac_v2_open,
    .close             = hg_gmac_v2_close,
    .ioctl             = hg_gmac_v2_ioctl,
    .send_data         = hg_gmac_v2_send_data,
    .send_scatter_data = hg_gmac_v2_send_scatter_data,
    .mdio_read         = hg_gmac_v2_mdio_read,
    .mdio_write        = hg_gmac_v2_mdio_write,
    .phy_event         = hg_gmac_v2_phy_event,
};

__init int32 hg_gmac_v2_attach(uint32 dev_id, struct hg_gmac_eva_v2 *gmac)
{
    gmac->opened                = 0;
    gmac->dev.dev.ops           = (const struct devobj_ops *)&gmacv2_ops;
    gmac->input_cb              = NULL;
    gmac->speed                 = 0;
    gmac->duplex                = -1;
    gmac->link_status           = LINK_DOWN;
    
    os_memset(gmac->mac_addr, 0xFF, 6);
    os_memset(&gmac->statistics, 0, sizeof(gmac->statistics));

    os_sema_init(&gmac->receive_sema, 0);
    os_mutex_init(&gmac->mdio_mutex);
    os_mutex_init(&gmac->send_mutex);

    if (gmac->mdio_pin) {
        gpio_set_dir(gmac->mdio_pin, GPIO_DIR_OUTPUT);
        gpio_set_dir(gmac->mdc_pin, GPIO_DIR_OUTPUT);
    }

    irq_disable(gmac->irq_num);
    dev_register(dev_id, (struct dev_obj *)gmac);
    
    return RET_OK;
}
