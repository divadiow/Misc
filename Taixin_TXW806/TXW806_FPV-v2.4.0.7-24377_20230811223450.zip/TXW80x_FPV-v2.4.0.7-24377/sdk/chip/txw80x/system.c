#include "sys_config.h"
#include "csi_config.h"
#include "soc.h"
#include "csi_core.h"
#include "csi_kernel.h"
#include "drv_usart.h"
#include "txw80x/ticker.h"
#include "osal/irq.h"
#include "osal/string.h"
#include "osal/semaphore.h"
#include "osal/task.h"
#include "osal/work.h"
#include "devid.h"
#include "lib/heap/sysheap.h"
#include "lib/lmac/lmac.h"
#include "lib/common/sysvar.h"
#include "lib/common/sysevt.h"
#include "lib/common/common.h"

extern int  main(void);
extern int  dev_init(void);
extern void device_init(void);

extern int32_t g_top_irqstack;
extern uint32_t __heap_start;
extern uint32_t __heap_end;
extern uint32_t __psram_heap_start;
extern uint32_t __psram_heap_end;
uint32 srampool_start = 0;
uint32 srampool_end   = 0;
uint32 psrampool_start = 0;
uint32 psrampool_end   = 0;
uint32 __sp_save[3];

#ifndef SYS_FACTORY_PARAM_SIZE
#define SYS_FACTORY_PARAM_SIZE 4
#endif
const uint16_t __used sys_factory_param[SYS_FACTORY_PARAM_SIZE / 2] __at_section("SYS_PARAM") = {SYS_FACTORY_PARAM_SIZE};

//为了不同工程,所以这里写一个空函数,即使没有save_boot_loader_addr也不会编译出错
__init __weak void save_boot_loader_addr() {};

__SYS_INIT void cache_open(void)
{
    sysctrl_cache_en();

    csi_cache_reset_profile();
    csi_cache_set_range(0, (uint32_t) & (__Vectors), CACHE_CRCR_1M, 0x1);
#if defined(PSRAM_HEAP)
    csi_cache_set_range(1, 0x18800000, CACHE_CRCR_2M, 0x1);
#endif
    csi_cache_enable_profile();
    csi_dcache_enable();
}

__SYS_INIT void system_clock_init(void)
{
    if (!sysctrl_cmu_sysclk_set(DEFAULT_SYS_CLK, 0)) {
        while (1);
    }
}

__SYS_INIT void SystemInit(void)
{
    uint32 i;

    srampool_start  = (uint32)&__heap_start;
    srampool_end    = (uint32)&__heap_end;
#if defined(PSRAM_HEAP)
    psrampool_start = (uint32)&__psram_heap_start;
    psrampool_end   = (uint32)&__psram_heap_end;
#endif

    /**
     * VDD LDO current limit set to 200mA
     * VDD LDO vol set to 1.15V
     */
    pmu_reg_write((uint32_t)&PMU->PMUCON4, ((PMU->PMUCON4 & ~((0x7UL << 28) | BIT(10))) | (0x5UL << 28)));

#if  SYS_CACHE_ENABLE
    cache_open();
#endif

    extern uint32 g_intstackbase;
    *((int *)((uint32)&g_intstackbase)) = 0xDEADBEEF;

    __set_VBR((uint32_t) & (__Vectors));

    SYSCTRL_REG_OPT_INIT();
    sys_reset_detect();
    sys_reset_pending_clr();

    sysctrl_efuse_pwron_init();

    pmu_boot_direct_run_dis();

//    sysctrl_err_resp_disable();
    sysctrl_cmu_init();

#ifndef FPGA_SUPPORT
//#if (DAC_BUG_FIXED==0)
//    sysctrl_dac_init();//en dac for ldo bug
//#endif
//    //pmu cfg
//    pmu_vdd_limit_cur_disable();
//    pd_reg_sec_opt_en();
//    pd_hxosc_en_sec(TRUE);
//#if (ADC_BUG_FIXED==0)
//    pmu_vdd_vol_set_sec(VDD_1P15V);
//#endif

    if (!sysctrl_cmu_upll_init()) {
        while (1);
    }

    system_clock_init();

#endif
//    sysctrl_lf_clk_cfg(); //from HOSC/1024 = 31.25k


#if defined(CONFIG_SEPARATE_IRQ_SP) && !defined(CONFIG_KERNEL_NONE)
    /* 801 not supported */
    __set_Int_SP((uint32_t)&g_top_irqstack);
    __set_CHR(__get_CHR() | CHR_ISE_Msk);
    VIC->TSPR = 0xFF;
#endif

    /* Clear active and pending IRQ */
    csi_vic_disable_all_irq();
    csi_vic_clear_all_pending_irq();
    csi_vic_clear_all_active();
    /* All peripheral interrupt priority is set to lowest */
    for (i = 0; i < IRQ_NUM; i++) {
        csi_vic_set_prio(i, 3);
    }

#ifdef CONFIG_KERNEL_NONE
    __enable_excp_irq();
#endif

    csi_coret_config(DEFAULT_SYS_CLK / CONFIG_SYSTICK_HZ, CORET_IRQn);    //1ms
#ifndef CONFIG_KERNEL_NONE
    csi_vic_enable_irq(CORET_IRQn);
#endif

#ifdef SYS_IRQ_STAT
    extern void SYS_IRQ_STAT_INIT(void);
    SYS_IRQ_STAT_INIT();
#endif

    request_irq(LVD_IRQn, lvd_irq_handler, 0);
    irq_enable(LVD_IRQn);
}

__init void malloc_init(void)
{
    uint32 flags = 0;
#ifdef MEM_TRACE
    flags |= SYSHEAP_FLAGS_MEM_LEAK_TRACE | SYSHEAP_FLAGS_MEM_OVERFLOW_CHECK;
#endif
    sysheap_init(&sram_heap, (void *)SYS_HEAP_START, SYS_HEAP_SIZE, flags);
#ifdef PSRAM_HEAP
    sysheap_init(&psram_heap, (void *)psrampool_start, psrampool_end - psrampool_start, flags);
#endif
}

__init void pre_main(void)
{
    extern struct os_workqueue main_wkq;
    extern uint32 *sysvar_mgr;
    malloc_init();
    csi_kernel_init();
    dev_init();
    device_init();
#ifdef CONFIG_SLEEP
    sys_sleepcb_init();
    sys_sleepdata_init();
#endif
    save_boot_loader_addr();
    sysctrl_rst_lmac_phy();
    sysctrl_efuse_validity_handle();
    VERSION_SHOW();
    sys_reset_show();
    sysvar_mgr    = os_zalloc(sizeof(uint32) * (1+SYSVAR_ID_MAX));
    sysvar_mgr[0] = SYSVAR_ID_MAX;
    os_workqueue_init(&main_wkq, "MAIN", OS_TASK_PRIORITY_NORMAL, 2048);
    mainwkq_monitor_init();
    os_run_func((os_run_func_t)main, 0, 0, 0);
    csi_kernel_start();
}

