#ifndef __SOC_H__
#define __SOC_H__

#include "tx_platform.h"

#define CONFIG_KERNEL_RHINO 1
#define SYSTEM_CLOCK DEFAULT_SYS_CLK

#endif