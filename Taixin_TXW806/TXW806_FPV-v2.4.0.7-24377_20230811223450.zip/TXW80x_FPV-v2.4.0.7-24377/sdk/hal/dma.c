#include "typesdef.h"
#include "list.h"
#include "errno.h"
#include "dev.h"
#include "hal/dma.h"

int32 dma_pause(struct dma_device *dma, uint32 ch)
{
    if (dma && ((const struct dma_hal_ops *)dma->dev.ops)->pause) {
        return ((const struct dma_hal_ops *)dma->dev.ops)->pause(dma, ch);
    }
    return RET_ERR;
}

int32 dma_resume(struct dma_device *dma, uint32 ch)
{
    if (dma && ((const struct dma_hal_ops *)dma->dev.ops)->resume) {
        return ((const struct dma_hal_ops *)dma->dev.ops)->resume(dma, ch);
    }
    return RET_ERR;
}

void dma_memcpy(struct dma_device *dma, void *dst, const void *src, uint32 n)
{
    ASSERT(dma && ((const struct dma_hal_ops *)dma->dev.ops)->xfer);

    struct dma_xfer_data xfer_data;
    xfer_data.dest              = (uint32)dst;
    xfer_data.src               = (uint32)src;
    xfer_data.element_per_width = DMA_SLAVE_BUSWIDTH_1_BYTE;
    xfer_data.element_num       = n;
    xfer_data.dir               = ((((uint32)dst) < SRAM_BASE) || (((uint32)src) < SRAM_BASE)) ? DMA_XFER_DIR_M2D : DMA_XFER_DIR_M2M;
    xfer_data.src_addr_mode     = DMA_XFER_MODE_INCREASE;
    xfer_data.dst_addr_mode     = DMA_XFER_MODE_INCREASE;
    xfer_data.dst_id            = 0;
    xfer_data.src_id            = 0;
    xfer_data.irq_hdl           = NULL;
//    xfer_data.irq_data          = 0;
    csi_dcache_clean_range((void *)src, n);
    csi_dcache_clean_range(dst, n);
    ((const struct dma_hal_ops *)dma->dev.ops)->xfer(dma, &xfer_data);
    csi_dcache_invalid_range(dst, n);
}

void dma_memset(struct dma_device *dma, void *dst, uint8 c, uint32 n)
{
    uint8 val = c;

    ASSERT(dma && ((const struct dma_hal_ops *)dma->dev.ops)->xfer);
    struct dma_xfer_data xfer_data;
    xfer_data.dest              = (uint32)dst;
    xfer_data.src               = (uint32)&val;
    xfer_data.element_per_width = DMA_SLAVE_BUSWIDTH_1_BYTE;
    xfer_data.element_num       = n;
    xfer_data.dir               = (((uint32)dst) < SRAM_BASE) ? DMA_XFER_DIR_M2D : DMA_XFER_DIR_M2M;
    xfer_data.src_addr_mode     = DMA_XFER_MODE_RECYCLE;
    xfer_data.dst_addr_mode     = DMA_XFER_MODE_INCREASE;
    xfer_data.dst_id            = 0;
    xfer_data.src_id            = 0;
    xfer_data.irq_hdl           = NULL;
//    xfer_data.irq_data          = 0;

    ((const struct dma_hal_ops *)dma->dev.ops)->xfer(dma, &xfer_data);
    csi_dcache_invalid_range(dst, n);
}

int32 dma_xfer(struct dma_device *dma, struct dma_xfer_data *data)
{
    if (dma && ((const struct dma_hal_ops *)dma->dev.ops)->xfer) {
        return ((const struct dma_hal_ops *)dma->dev.ops)->xfer(dma, data);
    }
    return RET_ERR;
}

int32 dma_status(struct dma_device *dma, uint32 ch)
{
    if (dma && ((const struct dma_hal_ops *)dma->dev.ops)->get_status) {
        return ((const struct dma_hal_ops *)dma->dev.ops)->get_status(dma, ch);
    }
    return RET_ERR;
}

int32 dma_stop(struct dma_device *dma, uint32 ch)
{
    if (dma && ((const struct dma_hal_ops *)dma->dev.ops)->stop) {
        return ((const struct dma_hal_ops *)dma->dev.ops)->stop(dma, ch);
    }
    return RET_ERR;
}
