#include "typesdef.h"
#include "list.h"
#include "errno.h"
#include "dev.h"
#include "devid.h"
#include "hal/jpeg.h"

int32 jpg_open(struct jpg_device *p_jpg)
{
    if(p_jpg) {
        return ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->open(p_jpg);
    }
    return RET_ERR;
}

int32 jpg_close(struct jpg_device *p_jpg)
{
    if(p_jpg) {
        return ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->close(p_jpg);
    }
    return RET_ERR;
}

int32 jpg_init(struct jpg_device *p_jpg, uint32 table_idx, uint32 qt)
{
    if(p_jpg && ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->init) {
        return ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->init(p_jpg, table_idx, qt);
    }
    return RET_ERR;
}

int32 jpg_set_size(struct jpg_device *p_jpg, uint32 h, uint32 w)
{
    if (p_jpg && ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->ioctl) {
        return ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->ioctl(p_jpg, JPG_IOCTL_CMD_SET_SIZE, h, w);
    }
    return RET_ERR;
}

int32 jpg_updata_dqt(struct jpg_device *p_jpg, uint32 *dqtbuf)
{
    if (p_jpg && ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->ioctl) {
        return ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->ioctl(p_jpg, JPG_IOCTL_CMD_UPDATE_QT, (uint32)dqtbuf, 0);
    }
    return RET_ERR;
}

int32 jpg_set_addr(struct jpg_device *p_jpg, uint32 addr, uint32 len)
{
    if (p_jpg && ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->ioctl) {
        return ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->ioctl(p_jpg, JPG_IOCTL_CMD_SET_ADR, addr, len);
    }
    return RET_ERR;
}

int32 jpg_set_qt(struct jpg_device *p_jpg, uint32 qt)
{
    if (p_jpg && ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->ioctl) {
        return ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->ioctl(p_jpg, JPG_IOCTL_CMD_SET_QT, qt, 0);
    }
    return RET_ERR;
}

int32 jpg_request_irq(struct jpg_device *p_jpg, jpg_irq_hdl isr, uint32 irq, void *dev_id)
{
    if (p_jpg && ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->request_irq) {
        return ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->request_irq(p_jpg, isr, irq, (uint32)dev_id);
    }
    return RET_ERR;
}

int32 jpg_release_irq(struct jpg_device *p_jpg, uint32 irq_flags)
{
    if (p_jpg && ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->release_irq) {
        return ((const struct jpeg_hal_ops *)p_jpg->dev.ops)->release_irq(p_jpg, irq_flags);
    }
    return RET_ERR;
}

